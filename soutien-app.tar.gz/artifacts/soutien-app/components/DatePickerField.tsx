import React, { useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet, Modal, Platform,
} from "react-native";
import DateTimePicker, { DateTimePickerEvent } from "@react-native-community/datetimepicker";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { formatDate, dateFromISO, dateToISO } from "@/utils/helpers";

interface Props {
  label: string;
  value: string;
  onChange: (isoDate: string) => void;
  minDate?: string;
  maxDate?: string;
}

export default function DatePickerField({ label, value, onChange, minDate, maxDate }: Props) {
  const colors = useColors();
  const [show, setShow] = useState(false);

  const dateValue = value ? dateFromISO(value) : new Date();

  const handleChange = (_event: DateTimePickerEvent, selected?: Date) => {
    if (Platform.OS === "android") setShow(false);
    if (selected) onChange(dateToISO(selected));
  };

  const styles = makeStyles(colors);

  if (Platform.OS === "web") {
    return (
      <View style={styles.wrapper}>
        <Text style={styles.label}>{label}</Text>
        <View style={styles.webField}>
          <Feather name="calendar" size={15} color={colors.accent} style={{ marginRight: 8 }} />
          <Text style={styles.displayText}>{value ? formatDate(value) : "—"}</Text>
          <input
            type="date"
            value={value}
            onChange={e => onChange(e.target.value)}
            style={{
              position: "absolute", inset: 0, opacity: 0, cursor: "pointer", fontSize: 16,
            }}
          />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.wrapper}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity style={styles.field} onPress={() => setShow(true)} activeOpacity={0.7}>
        <Feather name="calendar" size={15} color={colors.accent} />
        <Text style={styles.displayText}>{value ? formatDate(value) : "Sélectionner"}</Text>
        <Feather name="chevron-down" size={15} color={colors.mutedForeground} style={{ marginLeft: "auto" }} />
      </TouchableOpacity>

      {Platform.OS === "ios" ? (
        <Modal visible={show} transparent animationType="slide">
          <View style={styles.iosOverlay}>
            <View style={styles.iosSheet}>
              <View style={styles.iosHeader}>
                <TouchableOpacity onPress={() => setShow(false)}>
                  <Text style={styles.iosDone}>Annuler</Text>
                </TouchableOpacity>
                <Text style={styles.iosTitle}>{label}</Text>
                <TouchableOpacity onPress={() => setShow(false)}>
                  <Text style={[styles.iosDone, { color: colors.accent }]}>Valider</Text>
                </TouchableOpacity>
              </View>
              <DateTimePicker
                value={dateValue}
                mode="date"
                display="spinner"
                onChange={handleChange}
                minimumDate={minDate ? dateFromISO(minDate) : undefined}
                maximumDate={maxDate ? dateFromISO(maxDate) : undefined}
                locale="fr-DZ"
                style={{ width: "100%", height: 200 }}
              />
            </View>
          </View>
        </Modal>
      ) : (
        show && (
          <DateTimePicker
            value={dateValue}
            mode="date"
            display="default"
            onChange={handleChange}
            minimumDate={minDate ? dateFromISO(minDate) : undefined}
            maximumDate={maxDate ? dateFromISO(maxDate) : undefined}
          />
        )
      )}
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    wrapper: { marginBottom: 4 },
    label: {
      fontFamily: "Inter_500Medium", fontSize: 12,
      color: colors.mutedForeground, marginBottom: 6, marginTop: 12,
    },
    field: {
      flexDirection: "row", alignItems: "center", gap: 10,
      backgroundColor: colors.card, borderRadius: 10, padding: 13,
      borderWidth: 1, borderColor: colors.border,
    },
    webField: {
      flexDirection: "row", alignItems: "center",
      backgroundColor: colors.card, borderRadius: 10, padding: 13,
      borderWidth: 1, borderColor: colors.border,
      position: "relative", overflow: "hidden",
    },
    displayText: {
      fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground,
    },
    iosOverlay: {
      flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.4)",
    },
    iosSheet: {
      backgroundColor: colors.card, borderTopLeftRadius: 20, borderTopRightRadius: 20,
      paddingBottom: 30,
    },
    iosHeader: {
      flexDirection: "row", justifyContent: "space-between", alignItems: "center",
      paddingHorizontal: 16, paddingVertical: 14,
      borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    iosTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, color: colors.foreground },
    iosDone: { fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.mutedForeground },
  });
}
