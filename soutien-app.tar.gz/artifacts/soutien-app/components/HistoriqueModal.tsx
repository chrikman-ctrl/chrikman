import React, { useState, useMemo } from "react";
import {
  View, Text, StyleSheet, Modal, TouchableOpacity, TextInput,
  ScrollView, Alert, Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Archive, Formule } from "@/types";
import {
  FORMULES_OPTIONS, calculerDateFin, todayISO,
  formatDate, getResteDuArchive, addDays, moisOrdinalLabel, getTarifDefaut,
} from "@/utils/helpers";
import DatePickerField from "@/components/DatePickerField";

interface Props {
  eleveId: string;
  onClose: () => void;
}

interface EditState {
  mois: number;
  tarifConvenu: string;
  somme: string;
  dateDeb: string;
  dateFin: string;
}

export default function HistoriqueModal({ eleveId, onClose }: Props) {
  const { eleves, parametres, updateArchiveSommeDates, deleteArchive, addNextPeriode, toggleStatut } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = makeStyles(colors);

  const eleve = useMemo(() => eleves.find(e => e.id === eleveId), [eleves, eleveId]);

  const [editing, setEditing] = useState<EditState | null>(null);
  const [showAddPeriode, setShowAddPeriode] = useState(false);
  const [newFormule, setNewFormule] = useState<Formule>("MENS_2000");
  const [newDateDeb, setNewDateDeb] = useState(todayISO());
  const [newDateFin, setNewDateFin] = useState(calculerDateFin(todayISO(), "MENS_2000"));
  const [newTarifConvenu, setNewTarifConvenu] = useState("");
  const [newSomme, setNewSomme] = useState("");

  if (!eleve) return null;

  const topPad = Platform.OS === "web" ? 20 : insets.top + 8;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom + 16;

  const niveauConfig = parametres.niveauxConfig.find(n => n.code === eleve.niveau);

  // --- Edit archive ---
  const startEdit = (archive: Archive) => {
    setEditing({
      mois: archive.mois,
      tarifConvenu: String(archive.tarifDuMois),
      somme: String(archive.somme),
      dateDeb: archive.dateDeb,
      dateFin: archive.dateFin,
    });
  };

  const cancelEdit = () => setEditing(null);

  const saveEdit = () => {
    if (!editing) return;
    const tarif = parseFloat(editing.tarifConvenu);
    const s = parseFloat(editing.somme);
    if (isNaN(tarif) || tarif < 0 || isNaN(s) || s < 0) {
      Alert.alert("Erreur", "Saisissez des montants valides.");
      return;
    }
    updateArchiveSommeDates(eleveId, editing.mois, tarif, s, editing.dateDeb, editing.dateFin);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setEditing(null);
  };

  const handleDelete = (archive: Archive) => {
    if (eleve.archives.length <= 1) {
      Alert.alert("Impossible", "L'élève doit avoir au moins une période.");
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    Alert.alert(
      "Supprimer cette période ?",
      `${moisOrdinalLabel(archive.mois)} — ${formatDate(archive.dateDeb)} → ${formatDate(archive.dateFin)}`,
      [
        { text: "Annuler", style: "cancel" },
        { text: "Supprimer", style: "destructive", onPress: () => deleteArchive(eleveId, archive.mois) },
      ]
    );
  };

  // --- Add next period ---
  const openAddPeriode = () => {
    const lastArchive = eleve.archives[eleve.archives.length - 1];
    const startDate = lastArchive?.dateFin ? addDays(lastArchive.dateFin, 1) : todayISO();
    const f: Formule = "MENS_2000";
    const tarif = getTarifDefaut(f, niveauConfig);
    setNewFormule(f);
    setNewDateDeb(startDate);
    setNewDateFin(calculerDateFin(startDate, f));
    setNewTarifConvenu(tarif > 0 ? String(tarif) : "");
    setNewSomme(tarif > 0 ? String(tarif) : "");
    setShowAddPeriode(true);
  };

  const handleNewFormuleChange = (f: Formule) => {
    setNewFormule(f);
    const tarif = getTarifDefaut(f, niveauConfig);
    setNewTarifConvenu(tarif > 0 ? String(tarif) : "");
    setNewSomme(tarif > 0 ? String(tarif) : "");
    setNewDateFin(calculerDateFin(newDateDeb, f));
  };

  const handleNewDateDebChange = (iso: string) => {
    setNewDateDeb(iso);
    setNewDateFin(calculerDateFin(iso, newFormule));
  };

  const addVacancesNew = (days: number) => {
    if (newDateFin) setNewDateFin(addDays(newDateFin, days));
  };

  const handleAddPeriode = () => {
    const tarif = parseFloat(newTarifConvenu);
    const s = parseFloat(newSomme);
    if (isNaN(tarif) || tarif < 0 || isNaN(s) || s < 0) {
      Alert.alert("Erreur", "Montants invalides.");
      return;
    }
    addNextPeriode(eleveId, {
      formule: newFormule,
      dateDebut: newDateDeb,
      dateFin: newDateFin || calculerDateFin(newDateDeb, newFormule),
      tarifConvenu: tarif,
      somme: s,
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowAddPeriode(false);
    Alert.alert("Réinscrit ✓", "Nouvelle période enregistrée.");
  };

  const totalPaye = eleve.archives.reduce((s, a) => s + a.somme, 0);
  const totalDu = eleve.archives.reduce((s, a) => s + a.tarifDuMois, 0);
  const totalReste = totalDu - totalPaye;

  return (
    <Modal visible animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={[styles.container, { paddingTop: topPad }]}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
            <Feather name="chevron-down" size={22} color="#fff" />
          </TouchableOpacity>
          <View style={{ flex: 1, marginHorizontal: 8 }}>
            <Text style={styles.title} numberOfLines={1}>{eleve.nom}</Text>
            <Text style={styles.subtitle}>
              {eleve.niveau} · {eleve.genre === "F" ? "Fille" : "Garçon"} ·{" "}
              <Text style={{ color: eleve.statut === "ACTIF" ? colors.tealGreen : colors.warning }}>
                {eleve.statut === "ACTIF" ? "Actif" : "En pause"}
              </Text>
            </Text>
          </View>
          <TouchableOpacity
            style={[styles.statutToggle, eleve.statut === "ACTIF" ? styles.btnPause : styles.btnResume]}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              toggleStatut(eleveId);
            }}
          >
            <Feather name={eleve.statut === "ACTIF" ? "pause" : "play"} size={14} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Résumé financier */}
        <View style={styles.financeSummary}>
          <View style={styles.financeItem}>
            <Text style={styles.financeLabel}>Total payé</Text>
            <Text style={[styles.financeVal, { color: colors.paidText }]}>{totalPaye.toLocaleString("fr-DZ")} DA</Text>
          </View>
          <View style={styles.financeSep} />
          <View style={styles.financeItem}>
            <Text style={styles.financeLabel}>Total dû</Text>
            <Text style={styles.financeVal}>{totalDu.toLocaleString("fr-DZ")} DA</Text>
          </View>
          <View style={styles.financeSep} />
          <View style={styles.financeItem}>
            <Text style={styles.financeLabel}>Reste</Text>
            <Text style={[styles.financeVal, { color: totalReste > 0 ? colors.debtText : colors.paidText }]}>
              {totalReste > 0 ? `-${totalReste.toLocaleString("fr-DZ")} DA` : "Réglé ✓"}
            </Text>
          </View>
        </View>

        <ScrollView
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: botPad, paddingTop: 12 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={styles.sectionTitle}>
            Historique ({eleve.archives.length} période{eleve.archives.length > 1 ? "s" : ""})
          </Text>

          {eleve.archives.map(archive => {
            const reste = getResteDuArchive(archive);
            const hasDette = reste > 0;
            const isEditing = editing?.mois === archive.mois;

            return (
              <View key={archive.mois} style={[styles.archiveCard, hasDette && styles.archiveCardDette]}>
                <View style={styles.archiveHeader}>
                  <View style={[styles.moisBadge, hasDette ? styles.moisBadgeDette : styles.moisBadgeOk]}>
                    <Text style={[styles.moisText, { color: hasDette ? colors.debtText : colors.paidText }]}>
                      {archive.mois}
                    </Text>
                  </View>
                  <View style={{ flex: 1, marginHorizontal: 10 }}>
                    <Text style={styles.archiveMoisLabel}>{moisOrdinalLabel(archive.mois)}</Text>
                    <Text style={styles.archiveDateText}>
                      {formatDate(archive.dateDeb)} → {formatDate(archive.dateFin)}
                    </Text>
                    <Text style={styles.archiveFormuleText}>
                      {FORMULES_OPTIONS.find(f => f.value === archive.formule)?.label}
                    </Text>
                  </View>
                  <View style={[styles.statutBadge, hasDette ? styles.detteBadge : styles.regleBadge]}>
                    <Text style={[styles.statutText, hasDette ? styles.detteText : styles.regleText]}>
                      {hasDette ? `-${reste} DA` : "Réglé ✓"}
                    </Text>
                  </View>
                </View>

                {!isEditing && (
                  <View style={styles.archiveAmounts}>
                    <View style={styles.amountRow}>
                      <Text style={styles.amountLabel}>Tarif convenu</Text>
                      <Text style={styles.amountVal}>{archive.tarifDuMois.toLocaleString("fr-DZ")} DA</Text>
                    </View>
                    <View style={styles.amountRow}>
                      <Text style={styles.amountLabel}>Reçu</Text>
                      <Text style={[styles.amountVal, { color: colors.paidText }]}>
                        {archive.somme.toLocaleString("fr-DZ")} DA
                      </Text>
                    </View>
                    {hasDette && (
                      <View style={styles.amountRow}>
                        <Text style={[styles.amountLabel, { color: colors.debtText }]}>Reste dû</Text>
                        <Text style={[styles.amountVal, { color: colors.debtText }]}>
                          {reste.toLocaleString("fr-DZ")} DA
                        </Text>
                      </View>
                    )}
                    <View style={styles.archiveActions}>
                      <TouchableOpacity style={styles.editBtn} onPress={() => startEdit(archive)}>
                        <Feather name="edit-3" size={13} color={colors.accent} />
                        <Text style={styles.editBtnText}>Modifier</Text>
                      </TouchableOpacity>
                      {eleve.archives.length > 1 && (
                        <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(archive)}>
                          <Feather name="trash-2" size={13} color={colors.destructive} />
                        </TouchableOpacity>
                      )}
                    </View>
                  </View>
                )}

                {isEditing && editing && (
                  <View style={styles.editForm}>
                    <Text style={styles.editFormTitle}>
                      Modifier — {moisOrdinalLabel(archive.mois)}
                    </Text>

                    <Text style={styles.editLabel}>Tarif convenu (DA) — modifiable librement</Text>
                    <TextInput
                      style={styles.editInput}
                      value={editing.tarifConvenu}
                      onChangeText={t => setEditing({ ...editing, tarifConvenu: t })}
                      keyboardType="numeric"
                      placeholder={String(archive.tarifDuMois)}
                      placeholderTextColor={colors.mutedForeground}
                      autoFocus
                      selectTextOnFocus
                    />

                    <Text style={styles.editLabel}>Somme réellement reçue (DA)</Text>
                    <TextInput
                      style={styles.editInput}
                      value={editing.somme}
                      onChangeText={t => setEditing({ ...editing, somme: t })}
                      keyboardType="numeric"
                      placeholder={String(archive.somme)}
                      placeholderTextColor={colors.mutedForeground}
                      selectTextOnFocus
                    />

                    <DatePickerField
                      label="Date de début"
                      value={editing.dateDeb}
                      onChange={iso => setEditing({ ...editing, dateDeb: iso })}
                    />
                    <DatePickerField
                      label="Date de fin"
                      value={editing.dateFin}
                      onChange={iso => setEditing({ ...editing, dateFin: iso })}
                      minDate={editing.dateDeb}
                    />

                    <View style={styles.editBtnRow}>
                      <TouchableOpacity style={styles.cancelEditBtn} onPress={cancelEdit}>
                        <Text style={styles.cancelEditText}>Annuler</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.confirmEditBtn} onPress={saveEdit}>
                        <Feather name="check" size={15} color="#fff" />
                        <Text style={styles.confirmEditText}>Valider</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
              </View>
            );
          })}

          {!showAddPeriode ? (
            <TouchableOpacity style={styles.addPeriodeToggle} onPress={openAddPeriode}>
              <Feather name="plus-circle" size={18} color={colors.accent} />
              <Text style={styles.addPeriodeToggleText}>
                Enregistrer le {moisOrdinalLabel(eleve.moisCompteur + 1).toLowerCase()} (réinscription)
              </Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.addPeriodeForm}>
              <View style={styles.addPeriodeFormHeader}>
                <Text style={styles.sectionTitle}>
                  Nouvelle période — {moisOrdinalLabel(eleve.moisCompteur + 1)}
                </Text>
                <TouchableOpacity onPress={() => setShowAddPeriode(false)}>
                  <Feather name="x" size={18} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>

              <Text style={styles.editLabel}>Formule</Text>
              <View style={styles.chipGroup}>
                {FORMULES_OPTIONS.map(f => (
                  <TouchableOpacity
                    key={f.value}
                    style={[styles.chip, newFormule === f.value && styles.chipActive]}
                    onPress={() => handleNewFormuleChange(f.value)}
                  >
                    <Text style={[styles.chipText, newFormule === f.value && styles.chipTextActive]}>
                      {f.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <DatePickerField
                label="Date de début (pré-remplie : lendemain de la période précédente)"
                value={newDateDeb}
                onChange={handleNewDateDebChange}
              />

              {newFormule !== "SEANCE_500" && (
                <>
                  <DatePickerField
                    label="Date de fin (auto-calculée)"
                    value={newDateFin}
                    onChange={setNewDateFin}
                    minDate={newDateDeb}
                  />
                  <View style={styles.vacancesRow}>
                    <TouchableOpacity style={styles.vacBtn} onPress={() => addVacancesNew(7)}>
                      <Feather name="sun" size={11} color="#fff" />
                      <Text style={styles.vacBtnText}>+1 sem. vacances</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.vacBtn} onPress={() => addVacancesNew(14)}>
                      <Feather name="sun" size={11} color="#fff" />
                      <Text style={styles.vacBtnText}>+2 sem. vacances</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}

              <Text style={styles.editLabel}>
                Tarif convenu (DA) — tarif de base {niveauConfig?.tarif ?? 0} DA
              </Text>
              <TextInput
                style={styles.editInput}
                value={newTarifConvenu}
                onChangeText={t => { setNewTarifConvenu(t); setNewSomme(t); }}
                placeholder="Montant mensuel convenu"
                placeholderTextColor={colors.mutedForeground}
                keyboardType="numeric"
                selectTextOnFocus
              />

              <Text style={styles.editLabel}>Somme réellement reçue (DA)</Text>
              <TextInput
                style={styles.editInput}
                value={newSomme}
                onChangeText={setNewSomme}
                placeholder="Montant encaissé"
                placeholderTextColor={colors.mutedForeground}
                keyboardType="numeric"
                selectTextOnFocus
              />

              <TouchableOpacity style={styles.confirmAddBtn} onPress={handleAddPeriode}>
                <Feather name="plus" size={18} color="#fff" />
                <Text style={styles.confirmAddText}>Confirmer la réinscription</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    header: {
      flexDirection: "row", alignItems: "center",
      paddingHorizontal: 16, paddingVertical: 12, backgroundColor: colors.navyDeep,
    },
    closeBtn: { padding: 4, marginRight: 4 },
    title: { fontFamily: "Inter_700Bold", fontSize: 16, color: "#fff" },
    subtitle: { fontFamily: "Inter_400Regular", fontSize: 12, color: "#A0B4C8", marginTop: 2 },
    statutToggle: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
    btnPause: { backgroundColor: colors.warning },
    btnResume: { backgroundColor: colors.success },

    financeSummary: {
      flexDirection: "row", backgroundColor: colors.card,
      paddingVertical: 14, paddingHorizontal: 16,
      borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    financeItem: { flex: 1, alignItems: "center" },
    financeLabel: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, marginBottom: 4 },
    financeVal: { fontFamily: "Inter_700Bold", fontSize: 15, color: colors.foreground },
    financeSep: { width: 1, backgroundColor: colors.border, marginVertical: 4 },

    sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground, marginBottom: 12 },

    archiveCard: {
      backgroundColor: colors.card, borderRadius: 12, marginBottom: 10,
      borderWidth: 1, borderColor: colors.border, overflow: "hidden",
    },
    archiveCardDette: { borderColor: colors.debtText + "50" },
    archiveHeader: {
      flexDirection: "row", alignItems: "center",
      padding: 12, borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    moisBadge: { width: 36, height: 36, borderRadius: 18, justifyContent: "center", alignItems: "center" },
    moisBadgeOk: { backgroundColor: colors.paidBg },
    moisBadgeDette: { backgroundColor: colors.debtBg },
    moisText: { fontFamily: "Inter_700Bold", fontSize: 14 },
    archiveMoisLabel: { fontFamily: "Inter_700Bold", fontSize: 13, color: colors.foreground },
    archiveDateText: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, marginTop: 1 },
    archiveFormuleText: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, marginTop: 1 },
    statutBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
    regleBadge: { backgroundColor: colors.paidBg },
    detteBadge: { backgroundColor: colors.debtBg },
    statutText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
    regleText: { color: colors.paidText },
    detteText: { color: colors.debtText },

    archiveAmounts: { padding: 12 },
    amountRow: {
      flexDirection: "row", justifyContent: "space-between", paddingVertical: 6,
      borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    amountLabel: { fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground },
    amountVal: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground },
    archiveActions: { flexDirection: "row", alignItems: "center", marginTop: 10, gap: 8 },
    editBtn: {
      flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6,
      backgroundColor: colors.accent + "18", borderRadius: 8, paddingVertical: 8,
      borderWidth: 1, borderColor: colors.accent + "40",
    },
    editBtnText: { fontFamily: "Inter_500Medium", fontSize: 13, color: colors.accent },
    deleteBtn: {
      width: 36, height: 36, borderRadius: 8, backgroundColor: colors.debtBg,
      justifyContent: "center", alignItems: "center",
    },

    editForm: { padding: 14, backgroundColor: colors.background, borderTopWidth: 1, borderTopColor: colors.border },
    editFormTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground, marginBottom: 4 },
    editLabel: { fontFamily: "Inter_500Medium", fontSize: 12, color: colors.mutedForeground, marginBottom: 5, marginTop: 12 },
    editInput: {
      backgroundColor: colors.card, borderRadius: 8, padding: 12,
      borderWidth: 1, borderColor: colors.border,
      fontFamily: "Inter_400Regular", fontSize: 14, color: colors.foreground,
    },
    editBtnRow: { flexDirection: "row", gap: 10, marginTop: 14 },
    cancelEditBtn: {
      flex: 1, borderRadius: 8, padding: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center",
    },
    cancelEditText: { fontFamily: "Inter_500Medium", fontSize: 14, color: colors.mutedForeground },
    confirmEditBtn: {
      flex: 2, borderRadius: 8, padding: 12, backgroundColor: colors.accent,
      flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    },
    confirmEditText: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: "#fff" },

    addPeriodeToggle: {
      flexDirection: "row", alignItems: "center", gap: 10,
      backgroundColor: colors.card, borderRadius: 12, padding: 16,
      borderWidth: 1.5, borderColor: colors.accent + "80", borderStyle: "dashed", marginBottom: 12,
    },
    addPeriodeToggleText: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.accent, flex: 1 },

    addPeriodeForm: {
      backgroundColor: colors.card, borderRadius: 12, padding: 14,
      borderWidth: 1, borderColor: colors.border, marginBottom: 12,
    },
    addPeriodeFormHeader: {
      flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 0,
    },
    chipGroup: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 4 },
    chip: {
      borderRadius: 8, paddingHorizontal: 11, paddingVertical: 8,
      backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border,
    },
    chipActive: { backgroundColor: colors.navyDeep, borderColor: colors.navyDeep },
    chipText: { fontFamily: "Inter_500Medium", fontSize: 12, color: colors.foreground },
    chipTextActive: { color: "#fff" },
    vacancesRow: { flexDirection: "row", gap: 8, marginTop: 8, marginBottom: 4 },
    vacBtn: {
      flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
      gap: 5, backgroundColor: colors.warning, borderRadius: 7, paddingVertical: 7,
    },
    vacBtnText: { fontFamily: "Inter_500Medium", fontSize: 11, color: "#fff" },
    confirmAddBtn: {
      backgroundColor: colors.accent, borderRadius: 10, padding: 14,
      flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 16,
    },
    confirmAddText: { fontFamily: "Inter_700Bold", fontSize: 15, color: "#fff" },
  });
}
