import React, { useState, useEffect } from "react";
import {
  View, Text, StyleSheet, Modal, TouchableOpacity, TextInput,
  ScrollView, Alert, Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Formule, Genre, NiveauConfig } from "@/types";
import {
  FORMULES_OPTIONS, calculerDateFin, todayISO, addDays, getTarifDefaut,
} from "@/utils/helpers";
import DatePickerField from "@/components/DatePickerField";

interface Props {
  visible: boolean;
  onClose: () => void;
}

const GENRES: { value: Genre; label: string }[] = [
  { value: "G", label: "Garçon" },
  { value: "F", label: "Fille" },
];

export default function AddEleveModal({ visible, onClose }: Props) {
  const { addEleve, parametres } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = makeStyles(colors);

  const niveauxConfig = parametres.niveauxConfig;

  const [nom, setNom] = useState("");
  const [selectedNiveauCode, setSelectedNiveauCode] = useState<string>(niveauxConfig[0]?.code ?? "");
  const [genre, setGenre] = useState<Genre>("G");
  const [formule, setFormule] = useState<Formule>("MENS_2000");
  const [dateDebut, setDateDebut] = useState(todayISO());
  const [dateFin, setDateFin] = useState("");
  const [tarifConvenu, setTarifConvenu] = useState("");
  const [somme, setSomme] = useState("");
  const [errNom, setErrNom] = useState("");
  const [errSomme, setErrSomme] = useState("");

  const selectedNiveauConfig = niveauxConfig.find(n => n.code === selectedNiveauCode);

  useEffect(() => {
    if (visible) {
      const firstCode = niveauxConfig[0]?.code ?? "";
      setNom(""); setSelectedNiveauCode(firstCode);
      setGenre("G"); setFormule("MENS_2000");
      const today = todayISO();
      setDateDebut(today);
      setDateFin(calculerDateFin(today, "MENS_2000"));
      const tarif = getTarifDefaut("MENS_2000", niveauxConfig.find(n => n.code === firstCode));
      setTarifConvenu(tarif > 0 ? String(tarif) : "");
      setSomme(tarif > 0 ? String(tarif) : "");
      setErrNom(""); setErrSomme("");
    }
  }, [visible]);

  const handleFormuleChange = (f: Formule) => {
    setFormule(f);
    const tarif = getTarifDefaut(f, selectedNiveauConfig);
    setTarifConvenu(tarif > 0 ? String(tarif) : "");
    setSomme(tarif > 0 ? String(tarif) : "");
    setDateFin(calculerDateFin(dateDebut, f));
  };

  const handleNiveauChange = (config: NiveauConfig) => {
    setSelectedNiveauCode(config.code);
    if (formule !== "CODE_PROMO" && formule !== "SEANCE_500") {
      setTarifConvenu(String(config.tarif));
      setSomme(String(config.tarif));
    }
  };

  const handleTarifChange = (t: string) => {
    setTarifConvenu(t);
    setSomme(t);
  };

  const handleDateDebutChange = (iso: string) => {
    setDateDebut(iso);
    setDateFin(calculerDateFin(iso, formule));
  };

  const addVacances = (days: number) => {
    if (dateFin) setDateFin(addDays(dateFin, days));
  };

  const tarifNum = parseFloat(tarifConvenu) || 0;
  const sommeNum = parseFloat(somme) || 0;
  const solde = tarifNum - sommeNum;

  const handleSave = () => {
    let valid = true;
    if (!nom.trim()) { setErrNom("Le nom est obligatoire."); valid = false; }
    if (!somme || isNaN(sommeNum)) { setErrSomme("Saisissez un montant valide."); valid = false; }
    if (!valid) return;

    addEleve({
      nom: nom.trim().toUpperCase(),
      niveau: selectedNiveauCode,
      genre, formule,
      dateDebut,
      dateFin: dateFin || calculerDateFin(dateDebut, formule),
      tarifConvenu: tarifNum,
      somme: sommeNum,
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    onClose();
  };

  const topPad = Platform.OS === "web" ? 20 : insets.top + 8;

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={[styles.container, { paddingTop: topPad }]}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
            <Feather name="x" size={20} color={colors.foreground} />
          </TouchableOpacity>
          <Text style={styles.title}>Inscrire un Élève</Text>
          <TouchableOpacity onPress={handleSave} style={styles.saveBtn}>
            <Text style={styles.saveBtnText}>Enregistrer</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40 }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Niveau — dynamique depuis Paramètres */}
          <Text style={styles.label}>Niveau</Text>
          {niveauxConfig.length === 0 ? (
            <View style={styles.alertBox}>
              <Feather name="alert-triangle" size={14} color={colors.warning} />
              <Text style={styles.alertText}>Aucun niveau configuré. Allez dans Paramètres pour en ajouter.</Text>
            </View>
          ) : (
            <View style={styles.chipGroup}>
              {niveauxConfig.map(n => (
                <TouchableOpacity
                  key={n.code}
                  style={[styles.smallChip, selectedNiveauCode === n.code && styles.chipActive]}
                  onPress={() => handleNiveauChange(n)}
                >
                  <Text style={[styles.chipText, selectedNiveauCode === n.code && styles.chipTextActive]}>
                    {n.code}
                  </Text>
                  <Text style={[styles.chipSub, selectedNiveauCode === n.code && styles.chipTextActive]}>
                    {n.tarif} DA
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Formule */}
          <Text style={styles.label}>Formule de cours</Text>
          <View style={styles.chipGroup}>
            {FORMULES_OPTIONS.map(f => (
              <TouchableOpacity
                key={f.value}
                style={[styles.chip, formule === f.value && styles.chipActive]}
                onPress={() => handleFormuleChange(f.value)}
              >
                <Text style={[styles.chipText, formule === f.value && styles.chipTextActive]}>
                  {f.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Genre */}
          <Text style={styles.label}>Genre</Text>
          <View style={styles.chipGroup}>
            {GENRES.map(g => (
              <TouchableOpacity
                key={g.value}
                style={[styles.smallChip, genre === g.value && styles.chipActive,
                  genre === g.value && g.value === "F" && { backgroundColor: "#E84393" }
                ]}
                onPress={() => setGenre(g.value)}
              >
                <Text style={[styles.chipText, genre === g.value && styles.chipTextActive]}>
                  {g.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Nom */}
          <Text style={styles.label}>Nom & Prénom de l'élève</Text>
          <TextInput
            style={[styles.input, errNom ? styles.inputError : null]}
            value={nom}
            onChangeText={t => { setNom(t.toUpperCase()); setErrNom(""); }}
            placeholder="NOM PRÉNOM"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="characters"
          />
          {errNom ? <Text style={styles.errText}>{errNom}</Text> : null}

          {/* Dates */}
          <DatePickerField label="Date de début" value={dateDebut} onChange={handleDateDebutChange} />

          {formule !== "SEANCE_500" && (
            <>
              <DatePickerField
                label="Date de fin (auto-calculée, modifiable)"
                value={dateFin}
                onChange={setDateFin}
                minDate={dateDebut}
              />
              <View style={styles.vacancesRow}>
                <TouchableOpacity style={styles.vacBtn} onPress={() => addVacances(7)}>
                  <Feather name="sun" size={12} color="#fff" />
                  <Text style={styles.vacBtnText}>+1 sem. vacances</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.vacBtn} onPress={() => addVacances(14)}>
                  <Feather name="sun" size={12} color="#fff" />
                  <Text style={styles.vacBtnText}>+2 sem. vacances</Text>
                </TouchableOpacity>
              </View>
            </>
          )}

          {/* Tarif convenu — éditable */}
          <View style={styles.tarifSection}>
            <View style={styles.tarifRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.label}>Tarif convenu (DA)</Text>
                <TextInput
                  style={styles.input}
                  value={tarifConvenu}
                  onChangeText={handleTarifChange}
                  placeholder="Tarif mensuel pour cet élève"
                  placeholderTextColor={colors.mutedForeground}
                  keyboardType="numeric"
                  selectTextOnFocus
                />
              </View>
            </View>
            <Text style={styles.tarifHint}>
              Modifiable librement — le tarif de base du niveau est {selectedNiveauConfig?.tarif ?? 0} DA
            </Text>

            {/* Somme reçue */}
            <Text style={[styles.label, { marginTop: 12 }]}>Somme réellement reçue (DA)</Text>
            <TextInput
              style={[styles.input, errSomme ? styles.inputError : null]}
              value={somme}
              onChangeText={t => { setSomme(t); setErrSomme(""); }}
              placeholder="Montant encaissé aujourd'hui"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="numeric"
              selectTextOnFocus
            />
            {errSomme ? <Text style={styles.errText}>{errSomme}</Text> : null}

            {solde > 0 && (
              <View style={styles.alertBox}>
                <Feather name="alert-triangle" size={14} color={colors.debtText} />
                <Text style={styles.alertText}>
                  Paiement partiel — Dette enregistrée : {solde} DA
                </Text>
              </View>
            )}
            {solde < 0 && (
              <View style={[styles.alertBox, { borderColor: colors.paidText + "40", backgroundColor: colors.paidBg }]}>
                <Feather name="check-circle" size={14} color={colors.paidText} />
                <Text style={[styles.alertText, { color: colors.paidText }]}>
                  Paiement excédentaire de {Math.abs(solde)} DA
                </Text>
              </View>
            )}
          </View>

          {/* Récapitulatif */}
          <View style={styles.summaryBox}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryKey}>Niveau</Text>
              <Text style={styles.summaryVal}>{selectedNiveauCode}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryKey}>Formule</Text>
              <Text style={styles.summaryVal}>{FORMULES_OPTIONS.find(f => f.value === formule)?.label}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryKey}>Tarif convenu</Text>
              <Text style={styles.summaryVal}>{tarifConvenu || "0"} DA</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryKey}>Reçu</Text>
              <Text style={[styles.summaryVal, { color: colors.paidText }]}>{somme || "0"} DA</Text>
            </View>
            {solde > 0 && (
              <View style={styles.summaryRow}>
                <Text style={[styles.summaryKey, { color: colors.debtText }]}>Reste dû</Text>
                <Text style={[styles.summaryVal, { color: colors.debtText }]}>{solde} DA</Text>
              </View>
            )}
          </View>

          <TouchableOpacity style={styles.mainSaveBtn} onPress={handleSave}>
            <Feather name="user-plus" size={18} color="#fff" />
            <Text style={styles.mainSaveBtnText}>Enregistrer l'élève</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </Modal>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    header: {
      flexDirection: "row", alignItems: "center", justifyContent: "space-between",
      paddingHorizontal: 16, paddingVertical: 14,
      backgroundColor: colors.card, borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    closeBtn: { padding: 4 },
    title: { fontFamily: "Inter_600SemiBold", fontSize: 17, color: colors.foreground },
    saveBtn: { backgroundColor: colors.accent, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 7 },
    saveBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: "#fff" },

    label: {
      fontFamily: "Inter_500Medium", fontSize: 13, color: colors.mutedForeground,
      marginTop: 16, marginBottom: 6,
    },
    input: {
      backgroundColor: colors.card, borderRadius: 10, padding: 12,
      borderWidth: 1, borderColor: colors.border,
      fontFamily: "Inter_400Regular", fontSize: 14, color: colors.foreground,
    },
    inputError: { borderColor: colors.destructive },
    errText: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.destructive, marginTop: 4 },

    chipGroup: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
    chip: {
      borderRadius: 10, paddingHorizontal: 14, paddingVertical: 9,
      backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
    },
    smallChip: {
      borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8,
      backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
      alignItems: "center",
    },
    chipActive: { backgroundColor: colors.navyDeep, borderColor: colors.navyDeep },
    chipText: { fontFamily: "Inter_500Medium", fontSize: 13, color: colors.foreground },
    chipSub: { fontFamily: "Inter_400Regular", fontSize: 10, color: colors.mutedForeground, marginTop: 2 },
    chipTextActive: { color: "#fff" },

    vacancesRow: { flexDirection: "row", gap: 8, marginTop: 8 },
    vacBtn: {
      flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
      gap: 6, backgroundColor: colors.warning, borderRadius: 8, paddingVertical: 8,
    },
    vacBtnText: { fontFamily: "Inter_500Medium", fontSize: 12, color: "#fff" },

    tarifSection: {
      backgroundColor: colors.muted + "60", borderRadius: 12, padding: 14,
      marginTop: 16, borderWidth: 1, borderColor: colors.border,
    },
    tarifRow: { flexDirection: "row", gap: 10 },
    tarifHint: {
      fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground,
      marginTop: 6, fontStyle: "italic",
    },

    alertBox: {
      flexDirection: "row", alignItems: "center", gap: 8,
      backgroundColor: colors.debtBg, borderRadius: 8, padding: 10, marginTop: 10,
      borderWidth: 1, borderColor: colors.debtText + "40",
    },
    alertText: { fontFamily: "Inter_500Medium", fontSize: 13, color: colors.debtText, flex: 1 },

    summaryBox: {
      backgroundColor: colors.card, borderRadius: 10, padding: 14,
      borderWidth: 1, borderColor: colors.border, marginTop: 16,
    },
    summaryRow: {
      flexDirection: "row", justifyContent: "space-between", paddingVertical: 6,
      borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    summaryKey: { fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground },
    summaryVal: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground },

    mainSaveBtn: {
      backgroundColor: colors.accent, borderRadius: 12, padding: 16,
      flexDirection: "row", alignItems: "center", justifyContent: "center",
      gap: 10, marginTop: 16,
    },
    mainSaveBtnText: { fontFamily: "Inter_700Bold", fontSize: 16, color: "#fff" },
  });
}
