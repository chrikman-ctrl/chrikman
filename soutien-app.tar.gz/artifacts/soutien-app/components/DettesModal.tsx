import React, { useState, useMemo } from "react";
import {
  View, Text, StyleSheet, Modal, TouchableOpacity, TextInput,
  ScrollView, Alert, Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { formatDate, getResteDuArchive, moisOrdinalLabel, dateFromISO } from "@/utils/helpers";
import { Eleve, Archive } from "@/types";

interface Props {
  visible: boolean;
  onClose: () => void;
}

interface EleveDette {
  eleve: Eleve;
  archivesEnDette: Archive[];
  totalDette: number;
  joursRetard: number;
}

function calcJoursRetard(archives: Archive[]): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  let maxRetard = 0;
  for (const a of archives) {
    if (getResteDuArchive(a) > 0 && a.dateFin) {
      const fin = dateFromISO(a.dateFin);
      fin.setHours(0, 0, 0, 0);
      const jours = Math.floor((today.getTime() - fin.getTime()) / (1000 * 60 * 60 * 24));
      if (jours > maxRetard) maxRetard = jours;
    }
  }
  return maxRetard;
}

export default function DettesModal({ visible, onClose }: Props) {
  const { eleves, updateArchiveSommeDates } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = makeStyles(colors);

  const [payingEleve, setPayingEleve] = useState<string | null>(null);
  const [payingMois, setPayingMois] = useState<number | null>(null);
  const [montantPaiement, setMontantPaiement] = useState("");
  const [filter, setFilter] = useState<"tous" | "retard" | "recent">("tous");

  const topPad = Platform.OS === "web" ? 20 : insets.top + 8;

  const elevesEnDette: EleveDette[] = useMemo(() => {
    return eleves
      .filter(e => e.statut === "ACTIF")
      .map(eleve => {
        const archivesEnDette = eleve.archives.filter(a => getResteDuArchive(a) > 0);
        const totalDette = archivesEnDette.reduce((s, a) => s + getResteDuArchive(a), 0);
        const joursRetard = calcJoursRetard(archivesEnDette);
        return { eleve, archivesEnDette, totalDette, joursRetard };
      })
      .filter(e => e.totalDette > 0)
      .sort((a, b) => b.joursRetard - a.joursRetard);
  }, [eleves]);

  const filtered = useMemo(() => {
    if (filter === "retard") return elevesEnDette.filter(e => e.joursRetard > 7);
    if (filter === "recent") return elevesEnDette.filter(e => e.joursRetard <= 7);
    return elevesEnDette;
  }, [elevesEnDette, filter]);

  const totalDettesGlobal = elevesEnDette.reduce((s, e) => s + e.totalDette, 0);
  const elevesEnRetard = elevesEnDette.filter(e => e.joursRetard > 7).length;
  const elevesRecents = elevesEnDette.filter(e => e.joursRetard <= 7).length;

  const retardColor = (jours: number) => {
    if (jours <= 0) return colors.paidText;
    if (jours <= 7) return "#F39C12";
    if (jours <= 30) return "#E67E22";
    return colors.debtText;
  };

  const retardLabel = (jours: number) => {
    if (jours <= 0) return "Récent";
    if (jours === 1) return "1 jour de retard";
    if (jours <= 7) return `${jours} jours (récent)`;
    if (jours <= 30) return `${jours} jours ⚠️`;
    return `${jours} jours 🔴`;
  };

  const openPaiement = (eleveId: string, moisIdx: number) => {
    setPayingEleve(eleveId);
    setPayingMois(moisIdx);
    setMontantPaiement("");
  };

  const closePaiement = () => {
    setPayingEleve(null);
    setPayingMois(null);
    setMontantPaiement("");
  };

  const confirmerPaiement = () => {
    if (!payingEleve || payingMois === null) return;
    const montant = parseFloat(montantPaiement);
    if (isNaN(montant) || montant <= 0) {
      Alert.alert("Erreur", "Saisissez un montant valide.");
      return;
    }

    const eleve = eleves.find(e => e.id === payingEleve);
    const archive = eleve?.archives.find(a => a.mois === payingMois);
    if (!eleve || !archive) return;

    const nouvellesSomme = Math.min(archive.somme + montant, archive.tarifDuMois);
    updateArchiveSommeDates(
      payingEleve, payingMois,
      archive.tarifDuMois, nouvellesSomme,
      archive.dateDeb, archive.dateFin
    );
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    closePaiement();

    const resteApres = archive.tarifDuMois - nouvellesSomme;
    if (resteApres <= 0) {
      Alert.alert("✅ Réglé !", `${eleve.nom} — ${moisOrdinalLabel(payingMois)} soldé.`);
    } else {
      Alert.alert("Paiement enregistré", `Reste dû : ${resteApres.toLocaleString("fr-DZ")} DA`);
    }
  };

  const payerTotal = (eleveId: string, moisIdx: number) => {
    const eleve = eleves.find(e => e.id === eleveId);
    const archive = eleve?.archives.find(a => a.mois === moisIdx);
    if (!eleve || !archive) return;

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    Alert.alert(
      "Marquer comme réglé",
      `Enregistrer le paiement complet de ${getResteDuArchive(archive).toLocaleString("fr-DZ")} DA pour ${eleve.nom} — ${moisOrdinalLabel(moisIdx)} ?`,
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Confirmer", onPress: () => {
            updateArchiveSommeDates(
              eleveId, moisIdx,
              archive.tarifDuMois, archive.tarifDuMois,
              archive.dateDeb, archive.dateFin
            );
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          }
        },
      ]
    );
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={[styles.container, { paddingTop: topPad }]}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
            <Feather name="x" size={20} color="#fff" />
          </TouchableOpacity>
          <View style={{ flex: 1, marginHorizontal: 10 }}>
            <Text style={styles.headerTitle}>Suivi des Impayés</Text>
            <Text style={styles.headerSub}>
              {elevesEnDette.length} élève{elevesEnDette.length > 1 ? "s" : ""} en dette
              · {totalDettesGlobal.toLocaleString("fr-DZ")} DA total
            </Text>
          </View>
        </View>

        {/* Stats rapides */}
        <View style={styles.statsRow}>
          <View style={[styles.statCard, { backgroundColor: colors.debtBg }]}>
            <Text style={[styles.statNum, { color: colors.debtText }]}>{totalDettesGlobal.toLocaleString("fr-DZ")} DA</Text>
            <Text style={styles.statLabel}>Total impayé</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: "#FFF3CD" }]}>
            <Text style={[styles.statNum, { color: "#E67E22" }]}>{elevesEnRetard}</Text>
            <Text style={styles.statLabel}>En retard &gt;7j</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.statNum, { color: colors.mutedForeground }]}>{elevesRecents}</Text>
            <Text style={styles.statLabel}>Récents ≤7j</Text>
          </View>
        </View>

        {/* Filtres */}
        <View style={styles.filterRow}>
          {([
            { key: "tous", label: `Tous (${elevesEnDette.length})` },
            { key: "retard", label: `En retard (${elevesEnRetard})` },
            { key: "recent", label: `Récents (${elevesRecents})` },
          ] as const).map(f => (
            <TouchableOpacity
              key={f.key}
              style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
              onPress={() => setFilter(f.key)}
            >
              <Text style={[styles.filterChipText, filter === f.key && styles.filterChipTextActive]}>
                {f.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {filtered.length === 0 ? (
          <View style={styles.emptyState}>
            <Feather name="check-circle" size={48} color={colors.paidText} />
            <Text style={styles.emptyTitle}>Aucun impayé 🎉</Text>
            <Text style={styles.emptyText}>Tous vos élèves sont à jour.</Text>
          </View>
        ) : (
          <ScrollView
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40, paddingTop: 8 }}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {filtered.map(({ eleve, archivesEnDette, totalDette, joursRetard }) => (
              <View key={eleve.id} style={[
                styles.eleveCard,
                joursRetard > 30 ? styles.cardCritique :
                  joursRetard > 7 ? styles.cardRetard : styles.cardRecent
              ]}>
                {/* En-tête élève */}
                <View style={styles.eleveHeader}>
                  <View style={[styles.retardBadge, { backgroundColor: retardColor(joursRetard) + "20", borderColor: retardColor(joursRetard) + "60" }]}>
                    <Feather name="clock" size={12} color={retardColor(joursRetard)} />
                    <Text style={[styles.retardText, { color: retardColor(joursRetard) }]}>
                      {retardLabel(joursRetard)}
                    </Text>
                  </View>
                  <View style={[styles.detteTotalBadge, { backgroundColor: colors.debtBg }]}>
                    <Text style={[styles.detteTotalText, { color: colors.debtText }]}>
                      -{totalDette.toLocaleString("fr-DZ")} DA
                    </Text>
                  </View>
                </View>

                <View style={styles.eleveInfo}>
                  <Text style={[styles.eleveNom, eleve.genre === "F" && { color: "#E84393" }]}>
                    {eleve.nom}
                  </Text>
                  <Text style={styles.eleveNiveau}>{eleve.niveau}</Text>
                </View>

                {/* Détail par période */}
                {archivesEnDette.map(archive => {
                  const reste = getResteDuArchive(archive);
                  const isPayingThisOne = payingEleve === eleve.id && payingMois === archive.mois;
                  const jours = (() => {
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    const fin = dateFromISO(archive.dateFin);
                    fin.setHours(0, 0, 0, 0);
                    return Math.floor((today.getTime() - fin.getTime()) / (1000 * 60 * 60 * 24));
                  })();

                  return (
                    <View key={archive.mois} style={styles.archiveItem}>
                      <View style={styles.archiveTop}>
                        <View style={{ flex: 1 }}>
                          <Text style={styles.archiveMois}>{moisOrdinalLabel(archive.mois)}</Text>
                          <Text style={styles.archiveDates}>
                            {formatDate(archive.dateDeb)} → {formatDate(archive.dateFin)}
                          </Text>
                        </View>
                        <View style={{ alignItems: "flex-end" }}>
                          <Text style={styles.resteText}>
                            -{reste.toLocaleString("fr-DZ")} DA
                          </Text>
                          {jours > 0 && (
                            <Text style={[styles.joursText, { color: retardColor(jours) }]}>
                              {jours}j de retard
                            </Text>
                          )}
                        </View>
                      </View>

                      {/* Barre de progression du paiement */}
                      <View style={styles.progressContainer}>
                        <View style={[styles.progressFill, {
                          width: `${Math.max((archive.somme / archive.tarifDuMois) * 100, 0)}%` as any
                        }]} />
                      </View>
                      <Text style={styles.progressLabel}>
                        {archive.somme.toLocaleString("fr-DZ")} / {archive.tarifDuMois.toLocaleString("fr-DZ")} DA payé
                      </Text>

                      {!isPayingThisOne ? (
                        <View style={styles.actionBtns}>
                          <TouchableOpacity
                            style={styles.partielBtn}
                            onPress={() => openPaiement(eleve.id, archive.mois)}
                          >
                            <Feather name="plus" size={13} color={colors.accent} />
                            <Text style={styles.partielBtnText}>Paiement partiel</Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={styles.soldéBtn}
                            onPress={() => payerTotal(eleve.id, archive.mois)}
                          >
                            <Feather name="check" size={13} color="#fff" />
                            <Text style={styles.soldéBtnText}>Solder</Text>
                          </TouchableOpacity>
                        </View>
                      ) : (
                        <View style={styles.paiementForm}>
                          <Text style={styles.paiementFormTitle}>
                            Enregistrer un paiement — {moisOrdinalLabel(archive.mois)}
                          </Text>
                          <Text style={styles.paiementFormSub}>
                            Reste dû : {reste.toLocaleString("fr-DZ")} DA
                          </Text>
                          <View style={styles.paiementInputRow}>
                            <TextInput
                              style={styles.paiementInput}
                              value={montantPaiement}
                              onChangeText={setMontantPaiement}
                              placeholder={`Max : ${reste} DA`}
                              placeholderTextColor={colors.mutedForeground}
                              keyboardType="numeric"
                              autoFocus
                              selectTextOnFocus
                            />
                            <Text style={styles.paiementDA}>DA</Text>
                          </View>
                          <View style={styles.paiementBtns}>
                            <TouchableOpacity style={styles.cancelPaiement} onPress={closePaiement}>
                              <Text style={styles.cancelPaiementText}>Annuler</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={styles.confirmPaiement}
                              onPress={confirmerPaiement}
                            >
                              <Feather name="check" size={15} color="#fff" />
                              <Text style={styles.confirmPaiementText}>Valider</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      )}
                    </View>
                  );
                })}
              </View>
            ))}
          </ScrollView>
        )}
      </View>
    </Modal>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },

    header: {
      flexDirection: "row", alignItems: "center",
      paddingHorizontal: 16, paddingVertical: 14, backgroundColor: "#C0392B",
    },
    closeBtn: { padding: 4 },
    headerTitle: { fontFamily: "Inter_700Bold", fontSize: 17, color: "#fff" },
    headerSub: { fontFamily: "Inter_400Regular", fontSize: 12, color: "#FFCDD2", marginTop: 2 },

    statsRow: { flexDirection: "row", gap: 10, padding: 16, paddingBottom: 8 },
    statCard: { flex: 1, borderRadius: 10, padding: 12, alignItems: "center", gap: 4 },
    statNum: { fontFamily: "Inter_700Bold", fontSize: 16 },
    statLabel: { fontFamily: "Inter_400Regular", fontSize: 10, color: colors.mutedForeground, textAlign: "center" },

    filterRow: { flexDirection: "row", gap: 8, paddingHorizontal: 16, paddingBottom: 8 },
    filterChip: {
      borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6,
      backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
    },
    filterChipActive: { backgroundColor: "#C0392B", borderColor: "#C0392B" },
    filterChipText: { fontFamily: "Inter_500Medium", fontSize: 12, color: colors.mutedForeground },
    filterChipTextActive: { color: "#fff" },

    emptyState: { flex: 1, justifyContent: "center", alignItems: "center", gap: 14, padding: 40 },
    emptyTitle: { fontFamily: "Inter_700Bold", fontSize: 20, color: colors.paidText },
    emptyText: { fontFamily: "Inter_400Regular", fontSize: 14, color: colors.mutedForeground, textAlign: "center" },

    eleveCard: {
      borderRadius: 12, marginBottom: 12, padding: 14,
      borderWidth: 1.5, backgroundColor: colors.card,
    },
    cardCritique: { borderColor: colors.debtText, backgroundColor: colors.debtBg + "30" },
    cardRetard: { borderColor: "#E67E22" + "80", backgroundColor: "#FFF3CD" + "40" },
    cardRecent: { borderColor: "#F39C12" + "60", backgroundColor: colors.card },

    eleveHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
    retardBadge: {
      flexDirection: "row", alignItems: "center", gap: 5,
      borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1,
    },
    retardText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
    detteTotalBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
    detteTotalText: { fontFamily: "Inter_700Bold", fontSize: 14 },

    eleveInfo: { marginBottom: 12 },
    eleveNom: { fontFamily: "Inter_700Bold", fontSize: 16, color: colors.foreground },
    eleveNiveau: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginTop: 2 },

    archiveItem: {
      backgroundColor: colors.background, borderRadius: 10, padding: 12,
      marginBottom: 8, borderWidth: 1, borderColor: colors.border,
    },
    archiveTop: { flexDirection: "row", alignItems: "flex-start", marginBottom: 8 },
    archiveMois: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground },
    archiveDates: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, marginTop: 2 },
    resteText: { fontFamily: "Inter_700Bold", fontSize: 14, color: colors.debtText },
    joursText: { fontFamily: "Inter_500Medium", fontSize: 11, marginTop: 2 },

    progressContainer: {
      height: 8, backgroundColor: colors.muted, borderRadius: 4, overflow: "hidden", marginBottom: 4,
    },
    progressFill: { height: "100%", backgroundColor: colors.paidText, borderRadius: 4 },
    progressLabel: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, marginBottom: 10 },

    actionBtns: { flexDirection: "row", gap: 8 },
    partielBtn: {
      flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6,
      backgroundColor: colors.accent + "15", borderRadius: 8, paddingVertical: 9,
      borderWidth: 1, borderColor: colors.accent + "40",
    },
    partielBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.accent },
    soldéBtn: {
      flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6,
      backgroundColor: colors.paidText, borderRadius: 8, paddingVertical: 9,
    },
    soldéBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: "#fff" },

    paiementForm: {
      backgroundColor: colors.background, borderRadius: 10, padding: 12,
      borderWidth: 1, borderColor: colors.accent + "50", marginTop: 4,
    },
    paiementFormTitle: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground, marginBottom: 2 },
    paiementFormSub: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.debtText, marginBottom: 10 },
    paiementInputRow: {
      flexDirection: "row", alignItems: "center", gap: 8,
      backgroundColor: colors.card, borderRadius: 8, padding: 12,
      borderWidth: 1, borderColor: colors.accent, marginBottom: 10,
    },
    paiementInput: {
      flex: 1, fontFamily: "Inter_600SemiBold", fontSize: 18, color: colors.foreground,
    },
    paiementDA: { fontFamily: "Inter_400Regular", fontSize: 14, color: colors.mutedForeground },
    paiementBtns: { flexDirection: "row", gap: 8 },
    cancelPaiement: {
      flex: 1, borderRadius: 8, padding: 10, borderWidth: 1,
      borderColor: colors.border, alignItems: "center",
    },
    cancelPaiementText: { fontFamily: "Inter_500Medium", fontSize: 13, color: colors.mutedForeground },
    confirmPaiement: {
      flex: 2, backgroundColor: colors.accent, borderRadius: 8, padding: 10,
      flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6,
    },
    confirmPaiementText: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: "#fff" },
  });
}
