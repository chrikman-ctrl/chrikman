export type Formule = 'MENS_2000' | 'SEANCE_500' | 'CODE_PROMO';
export type Niveau = string;
export type Genre = 'G' | 'F';
export type Statut = 'ACTIF' | 'PAUSE';

export interface NiveauConfig {
  code: string;
  label: string;
  tarif: number;
}

export interface Archive {
  mois: number;
  dateDeb: string;
  dateFin: string;
  somme: number;
  formule: Formule;
  tarifDuMois: number;
}

export interface Eleve {
  id: string;
  nom: string;
  niveau: Niveau;
  genre: Genre;
  statut: Statut;
  dateDebut: string;
  dateFin: string;
  formule: Formule;
  moisCompteur: number;
  sommeMoisEnCours: number;
  tarifCustomFiche: number | null;
  archives: Archive[];
}

export interface HistoriqueMensuel {
  id: string;
  label: string;
  date: string;
  encaissement: number;
  partProf: number;
  partCreche: number;
  nbEleves: number;
}

export interface Parametres {
  nom: string;
  prenom: string;
  tauxProf: number;
  tauxCreche: number;
  darkMode: boolean;
  niveauxConfig: NiveauConfig[];
}
