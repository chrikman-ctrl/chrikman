import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Eleve, HistoriqueMensuel, Parametres, Formule, Niveau, Genre, Archive, NiveauConfig } from '@/types';
import {
  loadEleves, saveEleves, loadHistorique, saveHistorique,
  loadParametres, saveParametres, DEFAULT_PARAMETRES,
} from '@/utils/storage';
import {
  genId, todayISO, calculerDateFin, moisLabel,
} from '@/utils/helpers';

interface AppContextType {
  eleves: Eleve[];
  historique: HistoriqueMensuel[];
  parametres: Parametres;
  loading: boolean;
  // Eleve CRUD
  addEleve: (data: AddEleveData) => void;
  deleteEleve: (id: string) => void;
  toggleStatut: (id: string) => void;
  // Archive editing
  updateArchiveSommeDates: (eleveId: string, moisIdx: number, tarifConvenu: number, somme: number, dateDeb: string, dateFin: string) => void;
  deleteArchive: (eleveId: string, moisIdx: number) => void;
  addNextPeriode: (eleveId: string, data: AddPeriodeData) => void;
  // Comptabilité
  cloturerMois: () => void;
  // Parametres
  updateParametres: (p: Partial<Parametres>) => void;
  addNiveau: (config: NiveauConfig) => void;
  updateNiveauTarif: (code: string, tarif: number) => void;
  deleteNiveau: (code: string) => void;
  // Stats
  totalActifs: number;
  totalEncaissement: number;
  totalAttendu: number;
  totalPartProf: number;
  totalPartCreche: number;
}

export interface AddEleveData {
  nom: string;
  niveau: Niveau;
  genre: Genre;
  dateDebut: string;
  dateFin: string;
  formule: Formule;
  tarifConvenu: number;
  somme: number;
}

export interface AddPeriodeData {
  formule: Formule;
  dateDebut: string;
  dateFin: string;
  tarifConvenu: number;
  somme: number;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [eleves, setElevesState] = useState<Eleve[]>([]);
  const [historique, setHistoriqueState] = useState<HistoriqueMensuel[]>([]);
  const [parametres, setParametresState] = useState<Parametres>(DEFAULT_PARAMETRES);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [e, h, p] = await Promise.all([loadEleves(), loadHistorique(), loadParametres()]);
      setElevesState(e);
      setHistoriqueState(h);
      setParametresState(p);
      setLoading(false);
    })();
  }, []);

  const setEleves = useCallback((updated: Eleve[]) => {
    setElevesState(updated);
    saveEleves(updated);
  }, []);

  const setHistorique = useCallback((updated: HistoriqueMensuel[]) => {
    setHistoriqueState(updated);
    saveHistorique(updated);
  }, []);

  const addEleve = useCallback((data: AddEleveData) => {
    const newEleve: Eleve = {
      id: genId(),
      nom: data.nom,
      niveau: data.niveau,
      genre: data.genre,
      statut: 'ACTIF',
      dateDebut: data.dateDebut,
      dateFin: data.dateFin,
      formule: data.formule,
      moisCompteur: 1,
      sommeMoisEnCours: data.somme,
      tarifCustomFiche: data.formule === 'CODE_PROMO' ? data.tarifConvenu : null,
      archives: [{
        mois: 1,
        dateDeb: data.dateDebut,
        dateFin: data.dateFin,
        somme: data.somme,
        formule: data.formule,
        tarifDuMois: data.tarifConvenu,
      }],
    };
    setEleves([...eleves, newEleve]);
  }, [eleves, setEleves]);

  const deleteEleve = useCallback((id: string) => {
    setEleves(eleves.filter(e => e.id !== id));
  }, [eleves, setEleves]);

  const toggleStatut = useCallback((id: string) => {
    setEleves(eleves.map(e =>
      e.id === id ? { ...e, statut: e.statut === 'ACTIF' ? 'PAUSE' : 'ACTIF' } : e
    ));
  }, [eleves, setEleves]);

  const updateArchiveSommeDates = useCallback((
    eleveId: string, moisIdx: number,
    tarifConvenu: number, somme: number,
    dateDeb: string, dateFin: string
  ) => {
    setEleves(eleves.map(e => {
      if (e.id !== eleveId) return e;
      const archives = e.archives.map(a => {
        if (a.mois !== moisIdx) return a;
        return { ...a, somme, dateDeb, dateFin, tarifDuMois: tarifConvenu };
      });
      const derniere = archives[archives.length - 1];
      const isCurrent = e.moisCompteur === moisIdx;
      return {
        ...e,
        archives,
        sommeMoisEnCours: isCurrent ? somme : e.sommeMoisEnCours,
        tarifCustomFiche: e.formule === 'CODE_PROMO' && isCurrent ? tarifConvenu : e.tarifCustomFiche,
        dateDebut: derniere?.dateDeb ?? e.dateDebut,
        dateFin: derniere?.dateFin ?? e.dateFin,
      };
    }));
  }, [eleves, setEleves]);

  const deleteArchive = useCallback((eleveId: string, moisIdx: number) => {
    setEleves(eleves.map(e => {
      if (e.id !== eleveId) return e;
      if (e.archives.length <= 1) return e;
      const archives = e.archives
        .filter(a => a.mois !== moisIdx)
        .map((a, i) => ({ ...a, mois: i + 1 }));
      const derniere = archives[archives.length - 1];
      return {
        ...e, archives,
        moisCompteur: archives.length,
        dateDebut: derniere.dateDeb,
        dateFin: derniere.dateFin,
        sommeMoisEnCours: derniere.somme,
        formule: derniere.formule,
        tarifCustomFiche: derniere.formule === 'CODE_PROMO' ? derniere.tarifDuMois : null,
      };
    }));
  }, [eleves, setEleves]);

  const addNextPeriode = useCallback((eleveId: string, data: AddPeriodeData) => {
    setEleves(eleves.map(e => {
      if (e.id !== eleveId) return e;
      const nextMois = e.moisCompteur + 1;
      const newArchive: Archive = {
        mois: nextMois,
        dateDeb: data.dateDebut,
        dateFin: data.dateFin,
        somme: data.somme,
        formule: data.formule,
        tarifDuMois: data.tarifConvenu,
      };
      return {
        ...e,
        moisCompteur: nextMois,
        dateDebut: data.dateDebut,
        dateFin: data.dateFin,
        formule: data.formule,
        sommeMoisEnCours: data.somme,
        tarifCustomFiche: data.formule === 'CODE_PROMO' ? data.tarifConvenu : null,
        archives: [...e.archives, newArchive],
      };
    }));
  }, [eleves, setEleves]);

  const cloturerMois = useCallback(() => {
    const actifs = eleves.filter(e => e.statut === 'ACTIF');
    const encaissement = actifs.reduce((sum, e) => sum + e.sommeMoisEnCours, 0);
    const entry: HistoriqueMensuel = {
      id: genId(),
      label: moisLabel(),
      date: todayISO(),
      encaissement,
      partProf: Math.round(encaissement * parametres.tauxProf / 100),
      partCreche: Math.round(encaissement * parametres.tauxCreche / 100),
      nbEleves: actifs.length,
    };
    setHistorique([...historique, entry]);
    setEleves(eleves.map(e => ({ ...e, sommeMoisEnCours: 0 })));
  }, [eleves, historique, parametres, setEleves, setHistorique]);

  const updateParametres = useCallback((p: Partial<Parametres>) => {
    const updated = { ...parametres, ...p };
    setParametresState(updated);
    saveParametres(updated);
  }, [parametres]);

  const addNiveau = useCallback((config: NiveauConfig) => {
    const exists = parametres.niveauxConfig.some(n => n.code === config.code);
    if (exists) return;
    updateParametres({ niveauxConfig: [...parametres.niveauxConfig, config] });
  }, [parametres, updateParametres]);

  const updateNiveauTarif = useCallback((code: string, tarif: number) => {
    updateParametres({
      niveauxConfig: parametres.niveauxConfig.map(n => n.code === code ? { ...n, tarif } : n),
    });
  }, [parametres, updateParametres]);

  const deleteNiveau = useCallback((code: string) => {
    updateParametres({
      niveauxConfig: parametres.niveauxConfig.filter(n => n.code !== code),
    });
  }, [parametres, updateParametres]);

  const actifs = eleves.filter(e => e.statut === 'ACTIF');
  const totalActifs = actifs.length;
  const totalEncaissement = actifs.reduce((s, e) => s + e.sommeMoisEnCours, 0);
  const totalAttendu = actifs.reduce((s, e) => {
    const last = e.archives[e.archives.length - 1];
    return s + (last?.tarifDuMois ?? 0);
  }, 0);
  const totalPartProf = Math.round(totalEncaissement * parametres.tauxProf / 100);
  const totalPartCreche = Math.round(totalEncaissement * parametres.tauxCreche / 100);

  return (
    <AppContext.Provider value={{
      eleves, historique, parametres, loading,
      addEleve, deleteEleve, toggleStatut,
      updateArchiveSommeDates, deleteArchive, addNextPeriode,
      cloturerMois,
      updateParametres, addNiveau, updateNiveauTarif, deleteNiveau,
      totalActifs, totalEncaissement, totalAttendu, totalPartProf, totalPartCreche,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
