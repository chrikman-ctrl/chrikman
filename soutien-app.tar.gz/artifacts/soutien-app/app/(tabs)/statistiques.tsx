import React from "react";
import { View, Text, StyleSheet, ScrollView, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { getResteDu } from "@/utils/helpers";

export default function StatistiquesScreen() {
  const { eleves, historique } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = makeStyles(colors);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 + 34 : 60 + insets.bottom;

  const actifs = eleves.filter(e => e.statut === "ACTIF");
  const enPause = eleves.filter(e => e.statut === "PAUSE");
  const total = eleves.length;

  const niveaux = [...new Set(eleves.map(e => e.niveau))].sort();

  const parNiveau = niveaux.map(niv => ({
    niv,
    actifs: actifs.filter(e => e.niveau === niv).length,
    pause: enPause.filter(e => e.niveau === niv).length,
    total: eleves.filter(e => e.niveau === niv).length,
  })).filter(n => n.total > 0);

  const maxEleves = Math.max(...parNiveau.map(n => n.total), 1);

  const totalEncaisseActuel = actifs.reduce((s, e) => s + e.sommeMoisEnCours, 0);
  const totalDette = actifs.reduce((s, e) => {
    const last = e.archives[e.archives.length - 1];
    const r = getResteDu(last?.tarifDuMois ?? 0, e.sommeMoisEnCours);
    return s + (r > 0 ? r : 0);
  }, 0);

  const derniersHist = historique.slice(-6);
  const maxHist = Math.max(...derniersHist.map(h => h.encaissement), totalEncaisseActuel, 1);

  const nbGarcons = actifs.filter(e => e.genre === "G").length;
  const nbFilles = actifs.filter(e => e.genre === "F").length;

  const elevesEnDette = actifs.filter(e => {
    const last = e.archives[e.archives.length - 1];
    return getResteDu(last?.tarifDuMois ?? 0, e.sommeMoisEnCours) > 0;
  }).length;

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Statistiques</Text>
        <Text style={styles.headerSub}>Session 2026/2027</Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: botPad, paddingHorizontal: 16, paddingTop: 16 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.summaryGrid}>
          <View style={[styles.summaryCard, { backgroundColor: colors.navyDeep }]}>
            <Feather name="users" size={20} color={colors.tealGreen} />
            <Text style={styles.summaryNum}>{total}</Text>
            <Text style={styles.summaryLabel}>Total inscrits</Text>
          </View>
          <View style={[styles.summaryCard, { backgroundColor: colors.accent + "18" }]}>
            <Feather name="play-circle" size={20} color={colors.accent} />
            <Text style={[styles.summaryNum, { color: colors.accent }]}>{actifs.length}</Text>
            <Text style={styles.summaryLabel}>Actifs</Text>
          </View>
          <View style={[styles.summaryCard, { backgroundColor: colors.muted }]}>
            <Feather name="pause-circle" size={20} color={colors.mutedForeground} />
            <Text style={[styles.summaryNum, { color: colors.mutedForeground }]}>{enPause.length}</Text>
            <Text style={styles.summaryLabel}>En pause</Text>
          </View>
          <View style={[styles.summaryCard, { backgroundColor: colors.debtBg }]}>
            <Feather name="alert-circle" size={20} color={colors.debtText} />
            <Text style={[styles.summaryNum, { color: colors.debtText }]}>{elevesEnDette}</Text>
            <Text style={styles.summaryLabel}>Dettes</Text>
          </View>
        </View>

        {actifs.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Répartition Genre (Actifs)</Text>
            <View style={styles.genreRow}>
              <View style={styles.genreItem}>
                <View style={[styles.genreBar, {
                  height: Math.max((nbGarcons / actifs.length) * 80, 4),
                  backgroundColor: colors.navyDeep,
                }]} />
                <Text style={styles.genreNum}>{nbGarcons}</Text>
                <Text style={styles.genreLabel}>Garçons</Text>
              </View>
              <View style={styles.genreItem}>
                <View style={[styles.genreBar, {
                  height: Math.max((nbFilles / actifs.length) * 80, 4),
                  backgroundColor: "#E84393",
                }]} />
                <Text style={styles.genreNum}>{nbFilles}</Text>
                <Text style={styles.genreLabel}>Filles</Text>
              </View>
            </View>
          </View>
        )}

        {parNiveau.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Élèves par Niveau</Text>
            {parNiveau.map(({ niv, actifs: a, pause: p, total: t }) => (
              <View key={niv} style={styles.niveauRow}>
                <Text style={styles.niveauLabel}>{niv}</Text>
                <View style={styles.barTrack}>
                  <View style={[styles.barActive, {
                    width: `${Math.max((a / maxEleves) * 100, a > 0 ? 5 : 0)}%` as any,
                  }]} />
                  {p > 0 && (
                    <View style={[styles.barPause, {
                      width: `${Math.max((p / maxEleves) * 100, p > 0 ? 5 : 0)}%` as any,
                    }]} />
                  )}
                </View>
                <View style={styles.niveauCounts}>
                  <Text style={[styles.countBadge, { color: colors.accent }]}>{a} actif{a > 1 ? "s" : ""}</Text>
                  {p > 0 && <Text style={[styles.countBadge, { color: colors.mutedForeground }]}>{p} pause</Text>}
                </View>
              </View>
            ))}
            <View style={styles.legendRow}>
              <View style={[styles.legendDot, { backgroundColor: colors.accent }]} />
              <Text style={styles.legendText}>Actifs</Text>
              <View style={[styles.legendDot, { backgroundColor: colors.mutedForeground + "60", marginLeft: 12 }]} />
              <Text style={styles.legendText}>En pause</Text>
            </View>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Revenus Mensuels</Text>
          {derniersHist.length === 0 && totalEncaisseActuel === 0 ? (
            <View style={styles.emptyChart}>
              <Feather name="bar-chart-2" size={28} color={colors.mutedForeground} />
              <Text style={styles.emptyChartText}>Aucune donnée</Text>
            </View>
          ) : (
            <View style={styles.chartContainer}>
              {derniersHist.map(h => (
                <View key={h.id} style={styles.chartBar}>
                  <Text style={styles.chartAmount}>{(h.encaissement / 1000).toFixed(0)}k</Text>
                  <View style={[styles.barColumn, {
                    height: Math.max((h.encaissement / maxHist) * 100, 4),
                    backgroundColor: colors.navyDeep,
                  }]} />
                  <Text style={styles.chartMonth} numberOfLines={1}>{h.label.split(" ")[0].substr(0, 4)}</Text>
                </View>
              ))}
              {totalEncaisseActuel > 0 && (
                <View style={styles.chartBar}>
                  <Text style={[styles.chartAmount, { color: colors.accent }]}>
                    {(totalEncaisseActuel / 1000).toFixed(0)}k
                  </Text>
                  <View style={[styles.barColumn, {
                    height: Math.max((totalEncaisseActuel / maxHist) * 100, 4),
                    backgroundColor: colors.accent,
                  }]} />
                  <Text style={[styles.chartMonth, { color: colors.accent }]}>Actuel</Text>
                </View>
              )}
            </View>
          )}
        </View>

        {totalDette > 0 && (
          <View style={[styles.section, { backgroundColor: colors.debtBg, borderColor: colors.debtText + "40" }]}>
            <View style={styles.detteHeader}>
              <Feather name="alert-triangle" size={16} color={colors.debtText} />
              <Text style={[styles.sectionTitle, { color: colors.debtText, marginBottom: 0 }]}>
                Total des dettes en cours
              </Text>
            </View>
            <Text style={styles.detteTotal}>{totalDette.toLocaleString("fr-DZ")} DA</Text>
            <Text style={styles.detteDetail}>{elevesEnDette} élève(s) en défaut de paiement</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    header: { backgroundColor: colors.navyDeep, paddingHorizontal: 16, paddingVertical: 14 },
    headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#fff" },
    headerSub: { fontSize: 12, color: "#A0B4C8", marginTop: 2 },

    summaryGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 14 },
    summaryCard: { flex: 1, minWidth: "45%", borderRadius: 12, padding: 14, alignItems: "center", gap: 6 },
    summaryNum: { fontFamily: "Inter_700Bold", fontSize: 24, color: "#fff" },
    summaryLabel: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, textAlign: "center" },

    section: {
      backgroundColor: colors.card, borderRadius: 12, padding: 14,
      borderWidth: 1, borderColor: colors.border, marginBottom: 14,
    },
    sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground, marginBottom: 12 },

    genreRow: { flexDirection: "row", justifyContent: "space-around", alignItems: "flex-end", height: 110 },
    genreItem: { alignItems: "center", gap: 6 },
    genreBar: { width: 50, borderRadius: 6, minHeight: 4 },
    genreNum: { fontFamily: "Inter_700Bold", fontSize: 18, color: colors.foreground },
    genreLabel: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground },

    niveauRow: { flexDirection: "row", alignItems: "center", marginBottom: 10, gap: 10 },
    niveauLabel: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground, width: 36 },
    barTrack: {
      flex: 1, height: 12, backgroundColor: colors.muted, borderRadius: 6,
      flexDirection: "row", overflow: "hidden",
    },
    barActive: { height: "100%", backgroundColor: colors.accent, borderRadius: 6 },
    barPause: { height: "100%", backgroundColor: colors.mutedForeground + "60" },
    niveauCounts: { flexDirection: "row", gap: 6, width: 100, justifyContent: "flex-end" },
    countBadge: { fontFamily: "Inter_500Medium", fontSize: 11 },

    legendRow: { flexDirection: "row", alignItems: "center", marginTop: 8, gap: 6 },
    legendDot: { width: 10, height: 10, borderRadius: 5 },
    legendText: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground },

    chartContainer: { flexDirection: "row", alignItems: "flex-end", gap: 6, height: 130, paddingTop: 10 },
    chartBar: { flex: 1, alignItems: "center", gap: 4 },
    chartAmount: { fontFamily: "Inter_500Medium", fontSize: 10, color: colors.mutedForeground },
    barColumn: { width: "100%", borderRadius: 4, minHeight: 4 },
    chartMonth: { fontFamily: "Inter_400Regular", fontSize: 10, color: colors.mutedForeground },

    emptyChart: { alignItems: "center", paddingVertical: 20, gap: 8 },
    emptyChartText: { fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground },

    detteHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 8 },
    detteTotal: { fontFamily: "Inter_700Bold", fontSize: 22, color: colors.debtText },
    detteDetail: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.debtText, marginTop: 4 },
  });
}
