import React, { useState } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  TextInput, Switch, Alert, Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { exportJSON } from "@/utils/storage";
import { NiveauConfig } from "@/types";
import { genId } from "@/utils/helpers";

export default function ParametresScreen() {
  const {
    parametres, updateParametres, eleves,
    addNiveau, updateNiveauTarif, deleteNiveau,
  } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = makeStyles(colors);

  const [editNom, setEditNom] = useState(parametres.nom);
  const [editPrenom, setEditPrenom] = useState(parametres.prenom);
  const [editTauxProf, setEditTauxProf] = useState(String(parametres.tauxProf));
  const [editTauxCreche, setEditTauxCreche] = useState(String(parametres.tauxCreche));
  const [editingProfile, setEditingProfile] = useState(false);

  // Nouveau niveau
  const [newNiveauCode, setNewNiveauCode] = useState("");
  const [newNiveauTarif, setNewNiveauTarif] = useState("2000");
  const [showAddNiveau, setShowAddNiveau] = useState(false);

  // Tarifs en cours d'édition (par code)
  const [editingTarifs, setEditingTarifs] = useState<Record<string, string>>({});

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 + 34 : 60 + insets.bottom;

  const handleSaveProfile = () => {
    const tProf = parseInt(editTauxProf, 10);
    const tCreche = parseInt(editTauxCreche, 10);
    if (isNaN(tProf) || isNaN(tCreche) || tProf + tCreche !== 100) {
      Alert.alert("Erreur", "Les taux doivent être des entiers dont la somme est 100%.");
      return;
    }
    updateParametres({ nom: editNom.trim(), prenom: editPrenom.trim(), tauxProf: tProf, tauxCreche: tCreche });
    setEditingProfile(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("Enregistré ✓", "Profil mis à jour.");
  };

  const handleAddNiveau = () => {
    const code = newNiveauCode.trim().toUpperCase();
    if (!code) { Alert.alert("Erreur", "Saisissez un code de niveau."); return; }
    const tarif = parseInt(newNiveauTarif, 10);
    if (isNaN(tarif) || tarif < 0) { Alert.alert("Erreur", "Tarif invalide."); return; }
    if (parametres.niveauxConfig.some(n => n.code === code)) {
      Alert.alert("Erreur", `Le niveau "${code}" existe déjà.`); return;
    }
    addNiveau({ code, label: code, tarif });
    setNewNiveauCode("");
    setNewNiveauTarif("2000");
    setShowAddNiveau(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleSaveTarif = (code: string) => {
    const tarif = parseInt(editingTarifs[code] ?? "", 10);
    if (isNaN(tarif) || tarif < 0) { Alert.alert("Erreur", "Tarif invalide."); return; }
    updateNiveauTarif(code, tarif);
    setEditingTarifs(prev => { const next = { ...prev }; delete next[code]; return next; });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleDeleteNiveau = (n: NiveauConfig) => {
    const count = eleves.filter(e => e.niveau === n.code).length;
    Alert.alert(
      "Supprimer le niveau",
      `Supprimer "${n.code}" ?${count > 0 ? ` (${count} élève(s) concerné(s))` : ""}`,
      [
        { text: "Annuler", style: "cancel" },
        { text: "Supprimer", style: "destructive", onPress: () => deleteNiveau(n.code) },
      ]
    );
  };

  const handleExport = async () => {
    try {
      const json = await exportJSON();
      Alert.alert(
        "Exporter les données",
        `${eleves.length} élève(s) — données prêtes.\n\n${json.substring(0, 200)}...`,
        [{ text: "Fermer" }]
      );
    } catch {
      Alert.alert("Erreur", "Impossible d'exporter.");
    }
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Paramètres</Text>
        <Text style={styles.headerSub}>Gestion & Configuration</Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: botPad, paddingHorizontal: 16, paddingTop: 16 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* ── Niveaux & Tarifs ── */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Feather name="layers" size={16} color={colors.accent} />
            <Text style={styles.sectionTitle}>Niveaux & Tarifs Mensuels</Text>
          </View>
          <Text style={styles.sectionDesc}>
            Configurez les niveaux et leurs tarifs par défaut. Le tarif reste modifiable lors de l'inscription de chaque élève.
          </Text>

          {parametres.niveauxConfig.map(n => {
            const isEditing = n.code in editingTarifs;
            return (
              <View key={n.code} style={styles.niveauRow}>
                <View style={styles.niveauCodeBox}>
                  <Text style={styles.niveauCode}>{n.code}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  {isEditing ? (
                    <View style={styles.tarifEditRow}>
                      <TextInput
                        style={styles.tarifInput}
                        value={editingTarifs[n.code]}
                        onChangeText={t => setEditingTarifs(prev => ({ ...prev, [n.code]: t }))}
                        keyboardType="numeric"
                        autoFocus
                        selectTextOnFocus
                      />
                      <TouchableOpacity style={styles.saveTarifBtn} onPress={() => handleSaveTarif(n.code)}>
                        <Feather name="check" size={15} color="#fff" />
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.cancelTarifBtn}
                        onPress={() => setEditingTarifs(prev => { const next = { ...prev }; delete next[n.code]; return next; })}
                      >
                        <Feather name="x" size={15} color={colors.mutedForeground} />
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity
                      style={styles.tarifDisplay}
                      onPress={() => setEditingTarifs(prev => ({ ...prev, [n.code]: String(n.tarif) }))}
                    >
                      <Text style={styles.tarifValue}>{n.tarif.toLocaleString("fr-DZ")} DA</Text>
                      <Feather name="edit-2" size={13} color={colors.accent} />
                    </TouchableOpacity>
                  )}
                </View>
                <TouchableOpacity style={styles.deleteNiveauBtn} onPress={() => handleDeleteNiveau(n)}>
                  <Feather name="trash-2" size={14} color={colors.destructive} />
                </TouchableOpacity>
              </View>
            );
          })}

          {/* Ajouter un niveau */}
          {showAddNiveau ? (
            <View style={styles.addNiveauForm}>
              <Text style={styles.addNiveauTitle}>Nouveau niveau</Text>
              <View style={styles.addNiveauRow}>
                <TextInput
                  style={[styles.tarifInput, { flex: 1 }]}
                  value={newNiveauCode}
                  onChangeText={t => setNewNiveauCode(t.toUpperCase())}
                  placeholder="Ex: 2AS, TC..."
                  placeholderTextColor={colors.mutedForeground}
                  autoCapitalize="characters"
                  autoFocus
                />
                <TextInput
                  style={[styles.tarifInput, { width: 90 }]}
                  value={newNiveauTarif}
                  onChangeText={setNewNiveauTarif}
                  placeholder="Tarif DA"
                  placeholderTextColor={colors.mutedForeground}
                  keyboardType="numeric"
                  selectTextOnFocus
                />
              </View>
              <View style={styles.addNiveauBtns}>
                <TouchableOpacity style={styles.cancelBtnSmall} onPress={() => setShowAddNiveau(false)}>
                  <Text style={styles.cancelBtnSmallText}>Annuler</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.confirmBtnSmall} onPress={handleAddNiveau}>
                  <Feather name="plus" size={14} color="#fff" />
                  <Text style={styles.confirmBtnSmallText}>Ajouter</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <TouchableOpacity style={styles.addNiveauBtn} onPress={() => setShowAddNiveau(true)}>
              <Feather name="plus-circle" size={16} color={colors.accent} />
              <Text style={styles.addNiveauBtnText}>Ajouter un niveau</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* ── Mon profil ── */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Feather name="user" size={16} color={colors.accent} />
            <Text style={styles.sectionTitle}>Mon Profil</Text>
            {!editingProfile && (
              <TouchableOpacity style={styles.editBtn} onPress={() => {
                setEditNom(parametres.nom);
                setEditPrenom(parametres.prenom);
                setEditTauxProf(String(parametres.tauxProf));
                setEditTauxCreche(String(parametres.tauxCreche));
                setEditingProfile(true);
              }}>
                <Feather name="edit-2" size={14} color={colors.accent} />
              </TouchableOpacity>
            )}
          </View>

          {editingProfile ? (
            <>
              {[
                { label: "Nom", value: editNom, onChange: setEditNom, cap: "words" as const },
                { label: "Prénom", value: editPrenom, onChange: setEditPrenom, cap: "words" as const },
              ].map(f => (
                <View key={f.label} style={styles.inputRow}>
                  <Text style={styles.inputLabel}>{f.label}</Text>
                  <TextInput style={styles.input} value={f.value}
                    onChangeText={f.onChange} autoCapitalize={f.cap}
                    placeholderTextColor={colors.mutedForeground}
                  />
                </View>
              ))}
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>Ma part (%)</Text>
                <TextInput style={styles.input} value={editTauxProf}
                  onChangeText={t => { setEditTauxProf(t); setEditTauxCreche(String(100 - (parseInt(t) || 0))); }}
                  keyboardType="numeric" placeholderTextColor={colors.mutedForeground}
                />
              </View>
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>Part crèche (%)</Text>
                <TextInput style={styles.input} value={editTauxCreche}
                  onChangeText={t => { setEditTauxCreche(t); setEditTauxProf(String(100 - (parseInt(t) || 0))); }}
                  keyboardType="numeric" placeholderTextColor={colors.mutedForeground}
                />
              </View>
              <View style={styles.btnRow}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setEditingProfile(false)}>
                  <Text style={styles.cancelBtnText}>Annuler</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.saveBtn} onPress={handleSaveProfile}>
                  <Feather name="check" size={16} color="#fff" />
                  <Text style={styles.saveBtnText}>Enregistrer</Text>
                </TouchableOpacity>
              </View>
            </>
          ) : (
            <>
              {[
                { label: "Enseignant", value: `${parametres.prenom} ${parametres.nom}` },
                { label: "Ma part", value: `${parametres.tauxProf}%`, color: colors.paidText },
                { label: "Part crèche", value: `${parametres.tauxCreche}%`, color: colors.debtText },
              ].map(r => (
                <View key={r.label} style={styles.infoRow}>
                  <Text style={styles.infoLabel}>{r.label}</Text>
                  <Text style={[styles.infoValue, r.color ? { color: r.color } : null]}>{r.value}</Text>
                </View>
              ))}
            </>
          )}
        </View>

        {/* ── Apparence ── */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Feather name="moon" size={16} color={colors.accent} />
            <Text style={styles.sectionTitle}>Apparence</Text>
          </View>
          <View style={styles.switchRow}>
            <View>
              <Text style={styles.switchLabel}>Mode sombre</Text>
              <Text style={styles.switchSub}>Thème foncé pour l'interface</Text>
            </View>
            <Switch
              value={parametres.darkMode}
              onValueChange={val => updateParametres({ darkMode: val })}
              trackColor={{ false: colors.muted, true: colors.accent }}
              thumbColor="#fff"
            />
          </View>
        </View>

        {/* ── Informations ── */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Feather name="info" size={16} color={colors.accent} />
            <Text style={styles.sectionTitle}>Informations</Text>
          </View>
          {[
            { label: "Total inscrits", value: String(eleves.length) },
            { label: "Actifs", value: String(eleves.filter(e => e.statut === "ACTIF").length), color: colors.accent },
            { label: "En pause", value: String(eleves.filter(e => e.statut === "PAUSE").length), color: colors.mutedForeground },
            { label: "Session", value: "2026/2027" },
          ].map(r => (
            <View key={r.label} style={styles.infoRow}>
              <Text style={styles.infoLabel}>{r.label}</Text>
              <Text style={[styles.infoValue, r.color ? { color: r.color } : null]}>{r.value}</Text>
            </View>
          ))}
        </View>

        {/* ── Sauvegarde ── */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Feather name="hard-drive" size={16} color={colors.accent} />
            <Text style={styles.sectionTitle}>Sauvegarde</Text>
          </View>
          <Text style={styles.sectionDesc}>
            Exportez toutes vos données (élèves, historique, paramètres) au format JSON.
          </Text>
          <TouchableOpacity style={styles.exportBtn} onPress={handleExport}>
            <Feather name="share-2" size={16} color="#fff" />
            <Text style={styles.exportBtnText}>Exporter mes données (JSON)</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    header: { backgroundColor: colors.navyDeep, paddingHorizontal: 16, paddingVertical: 14 },
    headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#fff" },
    headerSub: { fontSize: 12, color: "#A0B4C8", marginTop: 2 },

    section: {
      backgroundColor: colors.card, borderRadius: 12, padding: 14,
      borderWidth: 1, borderColor: colors.border, marginBottom: 14,
    },
    sectionHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 },
    sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.foreground, flex: 1 },
    sectionDesc: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginBottom: 14, lineHeight: 18 },
    editBtn: { backgroundColor: colors.accent + "18", borderRadius: 8, padding: 6 },

    // Niveaux
    niveauRow: {
      flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 10,
      paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    niveauCodeBox: {
      backgroundColor: colors.navyDeep, borderRadius: 8, width: 52, height: 40,
      justifyContent: "center", alignItems: "center",
    },
    niveauCode: { fontFamily: "Inter_700Bold", fontSize: 13, color: "#fff" },
    tarifEditRow: { flexDirection: "row", alignItems: "center", gap: 8 },
    tarifInput: {
      backgroundColor: colors.background, borderRadius: 8, padding: 9,
      borderWidth: 1, borderColor: colors.accent,
      fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground,
      minWidth: 80,
    },
    saveTarifBtn: {
      backgroundColor: colors.accent, borderRadius: 8, width: 36, height: 36,
      justifyContent: "center", alignItems: "center",
    },
    cancelTarifBtn: {
      backgroundColor: colors.muted, borderRadius: 8, width: 36, height: 36,
      justifyContent: "center", alignItems: "center",
    },
    tarifDisplay: { flexDirection: "row", alignItems: "center", gap: 8 },
    tarifValue: { fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.foreground },
    deleteNiveauBtn: {
      backgroundColor: colors.debtBg, borderRadius: 8, width: 36, height: 36,
      justifyContent: "center", alignItems: "center",
    },
    addNiveauBtn: {
      flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8,
      backgroundColor: colors.accent + "12", borderRadius: 10, padding: 12,
      borderWidth: 1, borderColor: colors.accent + "40", borderStyle: "dashed",
    },
    addNiveauBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.accent },
    addNiveauForm: { marginTop: 8, padding: 12, backgroundColor: colors.background, borderRadius: 10 },
    addNiveauTitle: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground, marginBottom: 10 },
    addNiveauRow: { flexDirection: "row", gap: 10, marginBottom: 10 },
    addNiveauBtns: { flexDirection: "row", gap: 8 },
    cancelBtnSmall: {
      flex: 1, borderRadius: 8, padding: 10, borderWidth: 1, borderColor: colors.border, alignItems: "center",
    },
    cancelBtnSmallText: { fontFamily: "Inter_500Medium", fontSize: 13, color: colors.mutedForeground },
    confirmBtnSmall: {
      flex: 2, backgroundColor: colors.accent, borderRadius: 8, padding: 10,
      flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6,
    },
    confirmBtnSmallText: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: "#fff" },

    // Profil
    inputRow: { marginBottom: 10 },
    inputLabel: { fontFamily: "Inter_500Medium", fontSize: 12, color: colors.mutedForeground, marginBottom: 5 },
    input: {
      backgroundColor: colors.background, borderRadius: 8, padding: 11,
      borderWidth: 1, borderColor: colors.border,
      fontFamily: "Inter_400Regular", fontSize: 14, color: colors.foreground,
    },
    btnRow: { flexDirection: "row", gap: 10, marginTop: 8 },
    cancelBtn: {
      flex: 1, borderRadius: 8, padding: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center",
    },
    cancelBtnText: { fontFamily: "Inter_500Medium", fontSize: 14, color: colors.mutedForeground },
    saveBtn: {
      flex: 2, borderRadius: 8, padding: 12, backgroundColor: colors.accent,
      flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    },
    saveBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: "#fff" },

    infoRow: {
      flexDirection: "row", justifyContent: "space-between", alignItems: "center",
      paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    infoLabel: { fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground },
    infoValue: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground },

    switchRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
    switchLabel: { fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground },
    switchSub: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginTop: 2 },

    exportBtn: {
      backgroundColor: colors.navyDeep, borderRadius: 10, padding: 14,
      flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10,
    },
    exportBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: "#fff" },
  });
}
