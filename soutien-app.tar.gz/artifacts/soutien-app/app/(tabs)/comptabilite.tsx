import React, { useState } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { getResteDu } from "@/utils/helpers";
import { exportPdfDettes, exportPdfMensuel, exportPdfComptabilite } from "@/utils/pdfReports";
import DettesModal from "@/components/DettesModal";

export default function ComptabiliteScreen() {
  const {
    eleves, historique, totalActifs, totalEncaissement, totalAttendu,
    totalPartProf, totalPartCreche, parametres, cloturerMois,
  } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [showHistorique, setShowHistorique] = useState(false);
  const [showDettes, setShowDettes] = useState(false);
  const [pdfLoading, setPdfLoading] = useState<string | null>(null);

  const styles = makeStyles(colors);
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 + 34 : 60 + insets.bottom;

  const actifs = eleves.filter(e => e.statut === "ACTIF");
  const enPause = eleves.filter(e => e.statut === "PAUSE");
  const soldeImpaye = totalAttendu - totalEncaissement;

  const niveaux = [...new Set(actifs.map(e => e.niveau))].sort();
  const statsParNiveau = niveaux.map(niv => {
    const groupe = actifs.filter(e => e.niveau === niv);
    const revenu = groupe.reduce((s, e) => s + e.sommeMoisEnCours, 0);
    return { niv, count: groupe.length, revenu };
  });
  const maxRevenu = Math.max(...statsParNiveau.map(s => s.revenu), 1);
  const totalCumulHistorique = historique.reduce((s, h) => s + h.encaissement, 0);

  const handleCloturer = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    Alert.alert(
      "Clôturer le mois",
      `Archiver ${totalEncaissement.toLocaleString("fr-DZ")} DA pour ${totalActifs} élèves actifs ?`,
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Clôturer", style: "destructive",
          onPress: () => {
            cloturerMois();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            Alert.alert("✅ Mois clôturé", "Les totaux ont été archivés.");
          },
        },
      ]
    );
  };

  const handleExportPdf = async (type: "dettes" | "mensuel" | "comptabilite") => {
    setPdfLoading(type);
    try {
      if (type === "dettes") await exportPdfDettes(eleves, parametres);
      else if (type === "mensuel") await exportPdfMensuel(eleves, historique, parametres);
      else await exportPdfComptabilite(eleves, historique, parametres);
    } finally {
      setPdfLoading(null);
    }
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Comptabilité & Bilan</Text>
        <Text style={styles.headerSub}>Mois en cours · {totalActifs} élèves actifs</Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: botPad, paddingHorizontal: 16, paddingTop: 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Dashboard */}
        <View style={[styles.mainCard, { backgroundColor: colors.navyDeep }]}>
          <Text style={styles.mainCardLabel}>Total encaissé (mois en cours)</Text>
          <Text style={styles.mainCardVal}>{totalEncaissement.toLocaleString("fr-DZ")} DA</Text>
          <View style={styles.mainCardRow}>
            <Text style={styles.mainCardSub}>Attendu : {totalAttendu.toLocaleString("fr-DZ")} DA</Text>
            {soldeImpaye > 0 && (
              <View style={styles.imPayeBadge}>
                <Text style={styles.impayeText}>Impayé : {soldeImpaye.toLocaleString("fr-DZ")} DA</Text>
              </View>
            )}
          </View>
        </View>

        <View style={styles.dashGrid}>
          <View style={[styles.dashCard, { backgroundColor: colors.paidBg }]}>
            <Feather name="user-check" size={16} color={colors.paidText} />
            <Text style={[styles.dashLabel, { color: colors.paidText }]}>Ma Part ({parametres.tauxProf}%)</Text>
            <Text style={[styles.dashAmount, { color: colors.paidText }]}>
              {totalPartProf.toLocaleString("fr-DZ")} DA
            </Text>
          </View>
          <View style={[styles.dashCard, { backgroundColor: colors.debtBg }]}>
            <Feather name="home" size={16} color={colors.debtText} />
            <Text style={[styles.dashLabel, { color: colors.debtText }]}>Part Crèche ({parametres.tauxCreche}%)</Text>
            <Text style={[styles.dashAmount, { color: colors.debtText }]}>
              {totalPartCreche.toLocaleString("fr-DZ")} DA
            </Text>
          </View>
        </View>

        {/* Statuts */}
        <View style={styles.statutRow}>
          <View style={[styles.statutCard, { backgroundColor: colors.accent + "18" }]}>
            <Feather name="play-circle" size={18} color={colors.accent} />
            <Text style={[styles.statutNum, { color: colors.accent }]}>{actifs.length}</Text>
            <Text style={styles.statutLabel}>Actifs</Text>
          </View>
          <View style={[styles.statutCard, { backgroundColor: colors.muted }]}>
            <Feather name="pause-circle" size={18} color={colors.mutedForeground} />
            <Text style={[styles.statutNum, { color: colors.mutedForeground }]}>{enPause.length}</Text>
            <Text style={styles.statutLabel}>En pause</Text>
          </View>
          <View style={[styles.statutCard, { backgroundColor: colors.debtBg }]}>
            <Feather name="alert-circle" size={18} color={colors.debtText} />
            <Text style={[styles.statutNum, { color: colors.debtText }]}>
              {actifs.filter(e => {
                const last = e.archives[e.archives.length - 1];
                return getResteDu(last?.tarifDuMois ?? 0, e.sommeMoisEnCours) > 0;
              }).length}
            </Text>
            <Text style={styles.statutLabel}>Dettes</Text>
          </View>
        </View>

        {/* Bilan par niveau */}
        {statsParNiveau.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Répartition par Niveau</Text>
            {statsParNiveau.map(({ niv, count, revenu }) => {
              const pct = maxRevenu > 0 ? revenu / maxRevenu : 0;
              return (
                <View key={niv} style={styles.niveauRow}>
                  <View style={styles.niveauLeft}>
                    <Text style={styles.niveauLabel}>{niv}</Text>
                    <Text style={styles.niveauCount}>{count} élève{count > 1 ? "s" : ""}</Text>
                  </View>
                  <View style={styles.barContainer}>
                    <View style={[styles.barFill, { width: `${Math.max(pct * 100, 4)}%` as any }]} />
                  </View>
                  <Text style={styles.niveauRevenu}>{revenu.toLocaleString("fr-DZ")} DA</Text>
                </View>
              );
            })}
          </View>
        )}

        {/* PDF Export */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Exporter en PDF</Text>
          <Text style={styles.pdfDesc}>
            Générez un rapport PDF et partagez-le par email ou Google Drive.
          </Text>

          <TouchableOpacity
            style={styles.pdfBtn}
            onPress={() => handleExportPdf("dettes")}
            disabled={pdfLoading !== null}
          >
            {pdfLoading === "dettes"
              ? <ActivityIndicator size="small" color="#fff" />
              : <Feather name="alert-circle" size={16} color="#fff" />}
            <Text style={styles.pdfBtnText}>Rapport des Impayés</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.pdfBtn, { backgroundColor: colors.navyDeep }]}
            onPress={() => handleExportPdf("mensuel")}
            disabled={pdfLoading !== null}
          >
            {pdfLoading === "mensuel"
              ? <ActivityIndicator size="small" color="#fff" />
              : <Feather name="calendar" size={16} color="#fff" />}
            <Text style={styles.pdfBtnText}>État de Paiement Mensuel</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.pdfBtn, { backgroundColor: colors.success }]}
            onPress={() => handleExportPdf("comptabilite")}
            disabled={pdfLoading !== null}
          >
            {pdfLoading === "comptabilite"
              ? <ActivityIndicator size="small" color="#fff" />
              : <Feather name="pie-chart" size={16} color="#fff" />}
            <Text style={styles.pdfBtnText}>Comptabilité Générale</Text>
          </TouchableOpacity>
        </View>

        {/* Suivi des dettes */}
        <TouchableOpacity
          style={styles.dettesBtn}
          onPress={() => setShowDettes(true)}
        >
          <Feather name="alert-triangle" size={18} color="#fff" />
          <View style={{ flex: 1 }}>
            <Text style={styles.dettesBtnTitle}>Suivi des Impayés</Text>
            <Text style={styles.dettesBtnSub}>
              Voir les dettes · paiements partiels · jours de retard
            </Text>
          </View>
          <Feather name="chevron-right" size={18} color="#fff" />
        </TouchableOpacity>

        {/* Clôture */}
        <TouchableOpacity style={styles.cloturerBtn} onPress={handleCloturer}>
          <Feather name="archive" size={18} color="#fff" />
          <Text style={styles.cloturerText}>Clôturer le mois & Archiver</Text>
        </TouchableOpacity>

        {/* Historique */}
        <TouchableOpacity
          style={styles.histBtn}
          onPress={() => setShowHistorique(!showHistorique)}
        >
          <Feather name={showHistorique ? "chevron-up" : "chevron-down"} size={18} color={colors.primary} />
          <Text style={styles.histBtnText}>
            Historique ({historique.length} mois clos)
            {historique.length > 0 && ` · Cumul : ${totalCumulHistorique.toLocaleString("fr-DZ")} DA`}
          </Text>
        </TouchableOpacity>

        {showHistorique && historique.length > 0 && (
          <View style={styles.section}>
            {[...historique].reverse().map((h, i) => (
              <View key={h.id} style={[styles.histCard, i > 0 && { marginTop: 8 }]}>
                <View style={styles.histHeader}>
                  <Text style={styles.histLabel}>{h.label}</Text>
                  <Text style={styles.histDate}>{h.date}</Text>
                </View>
                <View style={styles.histRow}>
                  <Text style={styles.histKey}>Encaissement</Text>
                  <Text style={styles.histVal}>{h.encaissement.toLocaleString("fr-DZ")} DA</Text>
                </View>
                <View style={styles.histRow}>
                  <Text style={styles.histKey}>Ma Part</Text>
                  <Text style={[styles.histVal, { color: colors.paidText }]}>{h.partProf.toLocaleString("fr-DZ")} DA</Text>
                </View>
                <View style={styles.histRow}>
                  <Text style={styles.histKey}>Part Crèche</Text>
                  <Text style={[styles.histVal, { color: colors.debtText }]}>{h.partCreche.toLocaleString("fr-DZ")} DA</Text>
                </View>
                <View style={styles.histRow}>
                  <Text style={styles.histKey}>Élèves</Text>
                  <Text style={styles.histVal}>{h.nbEleves}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {showHistorique && historique.length === 0 && (
          <View style={styles.emptyHist}>
            <Feather name="inbox" size={32} color={colors.mutedForeground} />
            <Text style={styles.emptyHistText}>Aucun mois clôturé</Text>
          </View>
        )}
      </ScrollView>

      <DettesModal visible={showDettes} onClose={() => setShowDettes(false)} />
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    header: { backgroundColor: colors.navyDeep, paddingHorizontal: 16, paddingVertical: 14 },
    headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#fff" },
    headerSub: { fontSize: 12, color: "#A0B4C8", marginTop: 2 },

    mainCard: { borderRadius: 14, padding: 18, marginBottom: 10 },
    mainCardLabel: { fontFamily: "Inter_400Regular", fontSize: 12, color: "#A0B4C8" },
    mainCardVal: { fontFamily: "Inter_700Bold", fontSize: 28, color: colors.tealGreen, marginTop: 4 },
    mainCardRow: { flexDirection: "row", alignItems: "center", marginTop: 8, gap: 10 },
    mainCardSub: { fontFamily: "Inter_400Regular", fontSize: 12, color: "#7A8FA0" },
    imPayeBadge: { backgroundColor: colors.debtText + "30", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
    impayeText: { fontFamily: "Inter_500Medium", fontSize: 11, color: colors.debtText },

    dashGrid: { flexDirection: "row", gap: 10, marginBottom: 14 },
    dashCard: { flex: 1, borderRadius: 12, padding: 14, gap: 4 },
    dashLabel: { fontFamily: "Inter_400Regular", fontSize: 11 },
    dashAmount: { fontFamily: "Inter_700Bold", fontSize: 17 },

    statutRow: { flexDirection: "row", gap: 10, marginBottom: 16 },
    statutCard: { flex: 1, borderRadius: 12, padding: 12, alignItems: "center", gap: 4 },
    statutNum: { fontFamily: "Inter_700Bold", fontSize: 20 },
    statutLabel: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground },

    section: {
      backgroundColor: colors.card, borderRadius: 12, padding: 14,
      borderWidth: 1, borderColor: colors.border, marginBottom: 14,
    },
    sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground, marginBottom: 8 },
    pdfDesc: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginBottom: 12, lineHeight: 18 },

    pdfBtn: {
      backgroundColor: colors.debtText, borderRadius: 10, padding: 13,
      flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8,
    },
    pdfBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: "#fff" },

    niveauRow: { flexDirection: "row", alignItems: "center", marginBottom: 10, gap: 10 },
    niveauLeft: { width: 50 },
    niveauLabel: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground },
    niveauCount: { fontFamily: "Inter_400Regular", fontSize: 10, color: colors.mutedForeground },
    barContainer: { flex: 1, height: 10, backgroundColor: colors.muted, borderRadius: 5, overflow: "hidden" },
    barFill: { height: "100%", backgroundColor: colors.accent, borderRadius: 5 },
    niveauRevenu: { fontFamily: "Inter_600SemiBold", fontSize: 12, color: colors.foreground, width: 86, textAlign: "right" },

    dettesBtn: {
      backgroundColor: "#C0392B", borderRadius: 12, padding: 16,
      flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 10,
    },
    dettesBtnTitle: { fontFamily: "Inter_700Bold", fontSize: 15, color: "#fff" },
    dettesBtnSub: { fontFamily: "Inter_400Regular", fontSize: 11, color: "#FFCDD2", marginTop: 2 },

    cloturerBtn: {
      backgroundColor: colors.destructive, borderRadius: 12, padding: 16,
      flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 10,
    },
    cloturerText: { fontFamily: "Inter_700Bold", fontSize: 15, color: "#fff" },

    histBtn: {
      backgroundColor: colors.card, borderRadius: 12, padding: 14, marginBottom: 10,
      flexDirection: "row", alignItems: "center", gap: 10,
      borderWidth: 1, borderColor: colors.border,
    },
    histBtnText: { fontFamily: "Inter_500Medium", fontSize: 13, color: colors.primary, flex: 1 },

    histCard: {
      backgroundColor: colors.background, borderRadius: 10, padding: 12,
      borderWidth: 1, borderColor: colors.border,
    },
    histHeader: {
      flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8,
    },
    histLabel: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground },
    histDate: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground },
    histRow: {
      flexDirection: "row", justifyContent: "space-between", paddingVertical: 4,
      borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    histKey: { fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground },
    histVal: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.foreground },

    emptyHist: {
      alignItems: "center", padding: 30, gap: 10,
      backgroundColor: colors.card, borderRadius: 12, marginBottom: 14,
    },
    emptyHistText: { fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground },
  });
}
