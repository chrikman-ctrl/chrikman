import React, { useState, useMemo } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList,
  TextInput, Alert, Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { Eleve } from "@/types";
import { formatDate, getResteDu, isExpired } from "@/utils/helpers";
import AddEleveModal from "@/components/AddEleveModal";
import HistoriqueModal from "@/components/HistoriqueModal";

const STATUTS_FILTER = [
  { value: "TOUS", label: "Tous" },
  { value: "ACTIF", label: "Actifs" },
  { value: "PAUSE", label: "En pause" },
  { value: "REGLE", label: "Réglés" },
  { value: "DETTE", label: "Dettes" },
];

export default function ListeScreen() {
  const { eleves, toggleStatut, deleteEleve, totalActifs, parametres } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const [showAdd, setShowAdd] = useState(false);
  const [selectedEleveId, setSelectedEleveId] = useState<string | null>(null);
  const [filtreNiveau, setFiltreNiveau] = useState("TOUS");
  const [filtreStatut, setFiltreStatut] = useState("TOUS");
  const [recherche, setRecherche] = useState("");
  const [showNiveauFilter, setShowNiveauFilter] = useState(false);
  const [showStatutFilter, setShowStatutFilter] = useState(false);

  const niveaux = ["TOUS", ...parametres.niveauxConfig.map(n => n.code)];

  const filtered = useMemo(() => {
    return eleves.filter(e => {
      const matchNiveau = filtreNiveau === "TOUS" || e.niveau === filtreNiveau;
      const lastArchive = e.archives[e.archives.length - 1];
      const resteDu = getResteDu(lastArchive?.tarifDuMois ?? 0, e.sommeMoisEnCours);
      const matchStatut = (() => {
        if (filtreStatut === "TOUS") return true;
        if (filtreStatut === "ACTIF") return e.statut === "ACTIF";
        if (filtreStatut === "PAUSE") return e.statut === "PAUSE";
        if (filtreStatut === "REGLE") return resteDu <= 0;
        if (filtreStatut === "DETTE") return resteDu > 0 && e.statut === "ACTIF";
        return true;
      })();
      const matchRecherche = recherche === "" || e.nom.toLowerCase().includes(recherche.toLowerCase());
      return matchNiveau && matchStatut && matchRecherche;
    });
  }, [eleves, filtreNiveau, filtreStatut, recherche]);

  const styles = makeStyles(colors);

  const handleToggleStatut = (eleve: Eleve) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert(
      "Changer le statut",
      `Mettre ${eleve.nom} ${eleve.statut === "ACTIF" ? "en pause" : "actif"} ?`,
      [
        { text: "Annuler", style: "cancel" },
        { text: "Confirmer", onPress: () => toggleStatut(eleve.id) },
      ]
    );
  };

  const handleDelete = (eleve: Eleve) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    Alert.alert(
      "Supprimer l'élève",
      `Supprimer définitivement ${eleve.nom} ?`,
      [
        { text: "Annuler", style: "cancel" },
        { text: "Supprimer", style: "destructive", onPress: () => deleteEleve(eleve.id) },
      ]
    );
  };

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 + 34 : 60 + insets.bottom;

  const renderEleve = ({ item, index }: { item: Eleve; index: number }) => {
    const isPause = item.statut === "PAUSE";
    const lastArchive = item.archives[item.archives.length - 1];
    const resteDu = getResteDu(lastArchive?.tarifDuMois ?? 0, item.sommeMoisEnCours);
    const hasDette = resteDu > 0 && !isPause;
    const expired = isExpired(item.dateFin);

    return (
      <TouchableOpacity
        style={[
          styles.card,
          isPause && styles.cardPause,
          expired && !isPause && styles.cardExpired,
        ]}
        onPress={() => setSelectedEleveId(item.id)}
        activeOpacity={0.7}
      >
        <View style={styles.cardHeader}>
          <View style={styles.cardLeft}>
            <View style={[styles.numBadge, isPause && styles.numBadgePause]}>
              <Text style={[styles.numText, isPause && styles.numTextPause]}>{index + 1}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <View style={styles.nameRow}>
                <Text style={[
                  styles.nomText,
                  item.genre === "F" ? styles.nomFille : styles.nomGarcon,
                  isPause && styles.textPause,
                ]} numberOfLines={1}>
                  {item.nom}
                </Text>
                {isPause && (
                  <View style={styles.pauseBadge}>
                    <Feather name="pause-circle" size={11} color={colors.mutedForeground} />
                    <Text style={styles.pauseBadgeText}>Pause</Text>
                  </View>
                )}
              </View>
              <Text style={[styles.niveauText, isPause && styles.textPause]}>
                {item.niveau} · {item.archives.length > 1
                  ? `${item.archives.length} périodes`
                  : "1re période"}
              </Text>
            </View>
          </View>

          <View style={styles.cardRight}>
            <View style={[
              styles.statutBadge,
              isPause ? styles.pauseStatutBadge : hasDette ? styles.detteBadge : styles.regleBadge,
            ]}>
              <Text style={[
                styles.statutText,
                isPause ? styles.textPause : hasDette ? styles.detteText : styles.regleText,
              ]}>
                {isPause ? "—" : hasDette ? `-${resteDu} DA` : "Réglé ✓"}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.cardFooter}>
          <Text style={[styles.dateText, isPause && styles.textPause]}>
            <Feather name="calendar" size={11} /> {formatDate(item.dateDebut)} → {formatDate(item.dateFin)}
          </Text>
          <View style={styles.actionRow}>
            <TouchableOpacity
              style={[styles.actionBtn, isPause ? styles.btnResume : styles.btnPause]}
              onPress={() => handleToggleStatut(item)}
            >
              <Feather name={isPause ? "play" : "pause"} size={13} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.actionBtn, styles.btnDelete]} onPress={() => handleDelete(item)}>
              <Feather name="trash-2" size={13} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Liste des Élèves</Text>
          <Text style={styles.headerSub}>
            Copies à préparer : <Text style={styles.headerCount}>{totalActifs + 1}</Text>
            <Text style={styles.headerSubNote}> (inclut votre exemplaire)</Text>
          </Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={() => setShowAdd(true)}>
          <Feather name="user-plus" size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchRow}>
        <Feather name="search" size={16} color={colors.mutedForeground} style={{ marginRight: 8 }} />
        <TextInput
          style={styles.searchInput}
          placeholder="Rechercher un élève..."
          placeholderTextColor={colors.mutedForeground}
          value={recherche}
          onChangeText={setRecherche}
        />
        {recherche !== "" && (
          <TouchableOpacity onPress={() => setRecherche("")}>
            <Feather name="x" size={16} color={colors.mutedForeground} />
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.filterRow}>
        <TouchableOpacity
          style={styles.filterChip}
          onPress={() => { setShowNiveauFilter(!showNiveauFilter); setShowStatutFilter(false); }}
        >
          <Feather name="layers" size={13} color={colors.accent} />
          <Text style={styles.filterChipText}>{filtreNiveau === "TOUS" ? "Niveau" : filtreNiveau}</Text>
          <Feather name="chevron-down" size={13} color={colors.accent} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.filterChip}
          onPress={() => { setShowStatutFilter(!showStatutFilter); setShowNiveauFilter(false); }}
        >
          <Feather name="filter" size={13} color={colors.accent} />
          <Text style={styles.filterChipText}>
            {filtreStatut === "TOUS" ? "Statut" : STATUTS_FILTER.find(s => s.value === filtreStatut)?.label}
          </Text>
          <Feather name="chevron-down" size={13} color={colors.accent} />
        </TouchableOpacity>

        <Text style={styles.countText}>{filtered.length} élève{filtered.length > 1 ? "s" : ""}</Text>
      </View>

      {showNiveauFilter && (
        <View style={styles.dropdown}>
          {niveaux.map(n => (
            <TouchableOpacity
              key={n}
              style={[styles.dropdownItem, filtreNiveau === n && styles.dropdownItemActive]}
              onPress={() => { setFiltreNiveau(n); setShowNiveauFilter(false); }}
            >
              <Text style={[styles.dropdownText, filtreNiveau === n && styles.dropdownTextActive]}>
                {n === "TOUS" ? "Tous les niveaux" : n}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {showStatutFilter && (
        <View style={styles.dropdown}>
          {STATUTS_FILTER.map(s => (
            <TouchableOpacity
              key={s.value}
              style={[styles.dropdownItem, filtreStatut === s.value && styles.dropdownItemActive]}
              onPress={() => { setFiltreStatut(s.value); setShowStatutFilter(false); }}
            >
              <Text style={[styles.dropdownText, filtreStatut === s.value && styles.dropdownTextActive]}>
                {s.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={renderEleve}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: botPad, paddingTop: 8 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Feather name="users" size={40} color={colors.mutedForeground} />
            <Text style={styles.emptyTitle}>Aucun élève</Text>
            <Text style={styles.emptyText}>Appuyez sur + pour ajouter un élève</Text>
          </View>
        }
      />

      <AddEleveModal visible={showAdd} onClose={() => setShowAdd(false)} />
      {selectedEleveId && (
        <HistoriqueModal eleveId={selectedEleveId} onClose={() => setSelectedEleveId(null)} />
      )}
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    header: {
      flexDirection: "row", justifyContent: "space-between", alignItems: "center",
      paddingHorizontal: 16, paddingVertical: 14, backgroundColor: colors.navyDeep,
    },
    headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#fff" },
    headerSub: { fontSize: 12, color: "#A0B4C8", marginTop: 2 },
    headerCount: { fontFamily: "Inter_700Bold", color: colors.tealGreen, fontSize: 14 },
    headerSubNote: { fontSize: 11, color: "#7A8FA0" },
    addBtn: {
      backgroundColor: colors.accent, width: 42, height: 42,
      borderRadius: 21, justifyContent: "center", alignItems: "center",
    },
    searchRow: {
      flexDirection: "row", alignItems: "center",
      marginHorizontal: 16, marginVertical: 10,
      backgroundColor: colors.card, borderRadius: 10,
      paddingHorizontal: 12, paddingVertical: 10,
      borderWidth: 1, borderColor: colors.border,
    },
    searchInput: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 14, color: colors.foreground },
    filterRow: {
      flexDirection: "row", alignItems: "center",
      paddingHorizontal: 16, marginBottom: 6, gap: 8,
    },
    filterChip: {
      flexDirection: "row", alignItems: "center", gap: 5,
      backgroundColor: colors.card, borderRadius: 20,
      paddingHorizontal: 12, paddingVertical: 7,
      borderWidth: 1, borderColor: colors.border,
    },
    filterChipText: { fontFamily: "Inter_500Medium", fontSize: 12, color: colors.accent },
    countText: { marginLeft: "auto", fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground },
    dropdown: {
      marginHorizontal: 16, backgroundColor: colors.card, borderRadius: 10,
      borderWidth: 1, borderColor: colors.border, marginBottom: 8,
      shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3,
    },
    dropdownItem: { paddingHorizontal: 16, paddingVertical: 12 },
    dropdownItemActive: { backgroundColor: colors.accent + "18" },
    dropdownText: { fontFamily: "Inter_400Regular", fontSize: 14, color: colors.foreground },
    dropdownTextActive: { fontFamily: "Inter_600SemiBold", color: colors.accent },

    card: {
      backgroundColor: colors.card, borderRadius: 12, marginBottom: 10,
      padding: 14, borderWidth: 1, borderColor: colors.border,
      shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 1,
    },
    cardPause: { backgroundColor: colors.pauseBg, borderColor: colors.pauseBorder, opacity: 0.8 },
    cardExpired: { borderColor: colors.warning + "60" },
    cardHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
    cardLeft: { flexDirection: "row", alignItems: "center", flex: 1, gap: 10 },
    cardRight: { alignItems: "flex-end" },
    numBadge: {
      width: 32, height: 32, borderRadius: 16,
      backgroundColor: colors.navyDeep, justifyContent: "center", alignItems: "center",
    },
    numBadgePause: { backgroundColor: colors.muted },
    numText: { fontFamily: "Inter_700Bold", fontSize: 12, color: "#fff" },
    numTextPause: { color: colors.pauseText },
    nameRow: { flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" },
    nomText: { fontFamily: "Inter_600SemiBold", fontSize: 15, flexShrink: 1 },
    nomGarcon: { color: colors.foreground },
    nomFille: { color: "#E84393" },
    textPause: { color: colors.pauseText },
    niveauText: { fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginTop: 2 },
    pauseBadge: {
      flexDirection: "row", alignItems: "center", gap: 3,
      backgroundColor: colors.muted, borderRadius: 10, paddingHorizontal: 7, paddingVertical: 2,
    },
    pauseBadgeText: { fontFamily: "Inter_500Medium", fontSize: 10, color: colors.mutedForeground },
    statutBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
    regleBadge: { backgroundColor: colors.paidBg },
    detteBadge: { backgroundColor: colors.debtBg },
    pauseStatutBadge: { backgroundColor: colors.muted },
    statutText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
    regleText: { color: colors.paidText },
    detteText: { color: colors.debtText },
    cardFooter: {
      flexDirection: "row", justifyContent: "space-between", alignItems: "center",
      marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border,
    },
    dateText: { fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, flex: 1 },
    actionRow: { flexDirection: "row", gap: 6 },
    actionBtn: { width: 30, height: 30, borderRadius: 8, justifyContent: "center", alignItems: "center" },
    btnPause: { backgroundColor: colors.warning },
    btnResume: { backgroundColor: colors.success },
    btnDelete: { backgroundColor: colors.destructive },
    emptyState: { alignItems: "center", paddingTop: 80, gap: 10 },
    emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, color: colors.mutedForeground },
    emptyText: { fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground, textAlign: "center" },
  });
}
