const colors = {
  light: {
    text: '#1A1A2E',
    tint: '#00B894',

    background: '#F0F4F8',
    foreground: '#1A1A2E',

    card: '#FFFFFF',
    cardForeground: '#1A1A2E',

    primary: '#2C3E50',
    primaryForeground: '#FFFFFF',

    secondary: '#E8EDF2',
    secondaryForeground: '#2C3E50',

    muted: '#ECF0F1',
    mutedForeground: '#7F8C8D',

    accent: '#00B894',
    accentForeground: '#FFFFFF',

    destructive: '#E74C3C',
    destructiveForeground: '#FFFFFF',

    warning: '#F39C12',
    warningForeground: '#FFFFFF',

    success: '#27AE60',
    successForeground: '#FFFFFF',

    border: '#DCE3EA',
    input: '#DCE3EA',

    // Custom semantic
    navyDeep: '#2C3E50',
    tealGreen: '#00B894',
    pauseBg: '#F5F5F5',
    pauseText: '#AAAAAA',
    pauseBorder: '#DDDDDD',
    debtBg: '#FFF0EE',
    debtText: '#E74C3C',
    paidBg: '#EAF9F2',
    paidText: '#27AE60',
  },
  dark: {
    text: '#ECF0F1',
    tint: '#00D2A8',

    background: '#0F1923',
    foreground: '#ECF0F1',

    card: '#1A2639',
    cardForeground: '#ECF0F1',

    primary: '#00B894',
    primaryForeground: '#0F1923',

    secondary: '#1E2D40',
    secondaryForeground: '#ECF0F1',

    muted: '#1E2D40',
    mutedForeground: '#8899AA',

    accent: '#00D2A8',
    accentForeground: '#0F1923',

    destructive: '#FF6B6B',
    destructiveForeground: '#FFFFFF',

    warning: '#FDCB6E',
    warningForeground: '#0F1923',

    success: '#55EFC4',
    successForeground: '#0F1923',

    border: '#263248',
    input: '#263248',

    navyDeep: '#1A2639',
    tealGreen: '#00D2A8',
    pauseBg: '#1A1A1A',
    pauseText: '#666666',
    pauseBorder: '#333333',
    debtBg: '#2D1A1A',
    debtText: '#FF6B6B',
    paidBg: '#1A2D1A',
    paidText: '#55EFC4',
  },
  radius: 10,
};

export default colors;
