import { Formule, NiveauConfig } from '@/types';

export const DUREE_FORFAIT_JOURS = 21;

export const FORMULES_OPTIONS = [
  { value: 'MENS_2000' as Formule, label: 'Mensuel' },
  { value: 'SEANCE_500' as Formule, label: 'Séance unique' },
  { value: 'CODE_PROMO' as Formule, label: 'Cas social' },
];

export function getTarifDefaut(formule: Formule, niveauConfig: NiveauConfig | undefined): number {
  if (formule === 'SEANCE_500') return 500;
  if (formule === 'CODE_PROMO') return 0;
  return niveauConfig?.tarif ?? 2000;
}

export function calculerDateFin(dateDebStr: string, formule: Formule): string {
  if (!dateDebStr) return '';
  if (formule === 'SEANCE_500') return dateDebStr;
  const d = new Date(dateDebStr);
  d.setDate(d.getDate() + DUREE_FORFAIT_JOURS);
  return d.toISOString().split('T')[0];
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return '—';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

export function todayISO(): string {
  return new Date().toISOString().split('T')[0];
}

export function genId(): string {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

export function isExpired(dateFin: string): boolean {
  if (!dateFin) return false;
  return new Date(dateFin) < new Date();
}

export function getResteDu(tarifDuMois: number, sommeMoisEnCours: number): number {
  return tarifDuMois - sommeMoisEnCours;
}

export function getResteDuArchive(archive: { tarifDuMois: number; somme: number }): number {
  return archive.tarifDuMois - archive.somme;
}

export function moisLabel(): string {
  const now = new Date();
  const mois = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
  return `${mois[now.getMonth()]} ${now.getFullYear()}`;
}

export function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

const ORDINAUX = [
  '', 'Premier', 'Deuxième', 'Troisième', 'Quatrième', 'Cinquième',
  'Sixième', 'Septième', 'Huitième', 'Neuvième', 'Dixième',
  'Onzième', 'Douzième',
];

export function moisOrdinalLabel(moisNum: number): string {
  const label = ORDINAUX[moisNum];
  return label ? `${label} mois` : `Mois ${moisNum}`;
}

export function dateFromISO(isoStr: string): Date {
  const [y, m, d] = isoStr.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function dateToISO(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
