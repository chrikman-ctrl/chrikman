import AsyncStorage from '@react-native-async-storage/async-storage';
import { Eleve, HistoriqueMensuel, Parametres, NiveauConfig } from '@/types';

const KEYS = {
  ELEVES: 'soutien_eleves_v2',
  HISTORIQUE: 'soutien_historique_v1',
  PARAMETRES: 'soutien_parametres_v2',
};

export const DEFAULT_NIVEAUX_CONFIG: NiveauConfig[] = [
  { code: '1AM', label: '1re Année Moyenne', tarif: 2000 },
  { code: '2AM', label: '2e Année Moyenne', tarif: 2000 },
  { code: '3AM', label: '3e Année Moyenne', tarif: 2000 },
  { code: '4AM', label: '4e Année Moyenne', tarif: 2000 },
  { code: '1AS', label: '1re Année Secondaire', tarif: 2500 },
];

export const DEFAULT_PARAMETRES: Parametres = {
  nom: 'Touha',
  prenom: 'Mohamed',
  tauxProf: 85,
  tauxCreche: 15,
  darkMode: false,
  niveauxConfig: DEFAULT_NIVEAUX_CONFIG,
};

export async function loadEleves(): Promise<Eleve[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.ELEVES);
    if (!data) return [];
    const parsed: Eleve[] = JSON.parse(data);
    return parsed.map(e => ({ statut: 'ACTIF', ...e }));
  } catch {
    return [];
  }
}

export async function saveEleves(eleves: Eleve[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.ELEVES, JSON.stringify(eleves));
}

export async function loadHistorique(): Promise<HistoriqueMensuel[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.HISTORIQUE);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export async function saveHistorique(hist: HistoriqueMensuel[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.HISTORIQUE, JSON.stringify(hist));
}

export async function loadParametres(): Promise<Parametres> {
  try {
    const data = await AsyncStorage.getItem(KEYS.PARAMETRES);
    if (!data) return DEFAULT_PARAMETRES;
    const parsed = JSON.parse(data);
    return {
      ...DEFAULT_PARAMETRES,
      ...parsed,
      niveauxConfig: parsed.niveauxConfig ?? DEFAULT_NIVEAUX_CONFIG,
    };
  } catch {
    return DEFAULT_PARAMETRES;
  }
}

export async function saveParametres(params: Parametres): Promise<void> {
  await AsyncStorage.setItem(KEYS.PARAMETRES, JSON.stringify(params));
}

export async function exportJSON(): Promise<string> {
  const eleves = await loadEleves();
  const historique = await loadHistorique();
  const parametres = await loadParametres();
  return JSON.stringify({ eleves, historique, parametres, exportDate: new Date().toISOString() }, null, 2);
}

export async function importJSON(jsonStr: string): Promise<void> {
  const data = JSON.parse(jsonStr);
  if (data.eleves) await saveEleves(data.eleves);
  if (data.historique) await saveHistorique(data.historique);
  if (data.parametres) await saveParametres(data.parametres);
}
