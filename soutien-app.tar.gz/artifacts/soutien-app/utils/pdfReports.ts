import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform, Alert } from 'react-native';
import { Eleve, HistoriqueMensuel, Parametres } from '@/types';
import { getResteDuArchive, formatDate } from '@/utils/helpers';

function htmlBase(title: string, body: string): string {
  return `
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"/>
<style>
  body { font-family: Arial, sans-serif; margin: 28px; color: #1A1A2E; font-size: 13px; }
  h1 { font-size: 20px; color: #2C3E50; margin-bottom: 4px; }
  h2 { font-size: 15px; color: #00B894; margin-top: 20px; margin-bottom: 8px; }
  .meta { font-size: 11px; color: #7F8C8D; margin-bottom: 20px; }
  table { width: 100%; border-collapse: collapse; margin-top: 8px; }
  th { background: #2C3E50; color: #fff; padding: 8px 10px; text-align: left; font-size: 12px; }
  td { padding: 7px 10px; border-bottom: 1px solid #DCE3EA; font-size: 12px; }
  tr:nth-child(even) td { background: #F8FAFB; }
  .rouge { color: #E74C3C; font-weight: bold; }
  .vert { color: #27AE60; font-weight: bold; }
  .total { background: #EAF9F2; font-weight: bold; }
  .total td { border-top: 2px solid #00B894; }
  .badge-dette { background: #FFF0EE; color: #E74C3C; padding: 2px 8px; border-radius: 4px; font-weight: bold; }
  .badge-regle { background: #EAF9F2; color: #27AE60; padding: 2px 8px; border-radius: 4px; }
  .header-block { display: flex; justify-content: space-between; align-items: flex-start; }
  .summary-grid { display: flex; gap: 16px; margin: 16px 0; }
  .summary-card { flex: 1; border: 1px solid #DCE3EA; border-radius: 8px; padding: 12px; text-align: center; }
  .summary-card .val { font-size: 22px; font-weight: bold; color: #2C3E50; }
  .summary-card .lbl { font-size: 11px; color: #7F8C8D; margin-top: 4px; }
</style>
</head>
<body>
<div class="header-block">
  <div>
    <h1>${title}</h1>
    <div class="meta">Généré le ${new Date().toLocaleDateString('fr-DZ')} · Soutien-App 2026/2027</div>
  </div>
</div>
${body}
</body>
</html>`;
}

export async function exportPdfDettes(eleves: Eleve[], parametres: Parametres): Promise<void> {
  const actifs = eleves.filter(e => e.statut === 'ACTIF');
  const enDette = actifs.filter(e => {
    const totalDu = e.archives.reduce((s, a) => s + a.tarifDuMois, 0);
    const totalPaye = e.archives.reduce((s, a) => s + a.somme, 0);
    return totalDu > totalPaye;
  });

  const totalDettes = enDette.reduce((s, e) => {
    const du = e.archives.reduce((a, arc) => a + arc.tarifDuMois, 0);
    const paye = e.archives.reduce((a, arc) => a + arc.somme, 0);
    return s + (du - paye);
  }, 0);

  const rows = enDette.map((e, i) => {
    const totalDu = e.archives.reduce((s, a) => s + a.tarifDuMois, 0);
    const totalPaye = e.archives.reduce((s, a) => s + a.somme, 0);
    const reste = totalDu - totalPaye;
    return `<tr>
      <td>${i + 1}</td>
      <td><strong>${e.nom}</strong></td>
      <td>${e.niveau}</td>
      <td>${totalDu.toLocaleString('fr-DZ')} DA</td>
      <td class="vert">${totalPaye.toLocaleString('fr-DZ')} DA</td>
      <td class="rouge">${reste.toLocaleString('fr-DZ')} DA</td>
    </tr>`;
  }).join('');

  const body = `
<div class="summary-grid">
  <div class="summary-card">
    <div class="val rouge">${enDette.length}</div>
    <div class="lbl">Élèves en impayé</div>
  </div>
  <div class="summary-card">
    <div class="val rouge">${totalDettes.toLocaleString('fr-DZ')} DA</div>
    <div class="lbl">Total des dettes</div>
  </div>
</div>
<table>
  <thead><tr>
    <th>#</th><th>Nom de l'élève</th><th>Niveau</th>
    <th>Total dû</th><th>Montant réglé</th><th>Reste à payer</th>
  </tr></thead>
  <tbody>${rows || '<tr><td colspan="6" style="text-align:center;color:#27AE60;">Aucun impayé ✓</td></tr>'}</tbody>
  <tr class="total"><td colspan="4"></td>
    <td colspan="2">Total : <span class="rouge">${totalDettes.toLocaleString('fr-DZ')} DA</span></td>
  </tr>
</table>`;

  await generateAndShare(htmlBase('Rapport des Impayés (Dettes)', body), 'rapport_dettes');
}

export async function exportPdfMensuel(
  eleves: Eleve[], historique: HistoriqueMensuel[], parametres: Parametres
): Promise<void> {
  const actifs = eleves.filter(e => e.statut === 'ACTIF');
  const totalAttendu = actifs.reduce((s, e) => {
    const derniereArchive = e.archives[e.archives.length - 1];
    return s + (derniereArchive?.tarifDuMois ?? 0);
  }, 0);
  const totalEnc = actifs.reduce((s, e) => s + e.sommeMoisEnCours, 0);
  const soldeImpaye = totalAttendu - totalEnc;
  const partProf = Math.round(totalEnc * parametres.tauxProf / 100);
  const partCreche = Math.round(totalEnc * parametres.tauxCreche / 100);

  const rows = actifs.map((e, i) => {
    const derniereArchive = e.archives[e.archives.length - 1];
    const tarifDu = derniereArchive?.tarifDuMois ?? 0;
    const recu = e.sommeMoisEnCours;
    const reste = tarifDu - recu;
    return `<tr>
      <td>${i + 1}</td>
      <td><strong>${e.nom}</strong></td>
      <td>${e.niveau}</td>
      <td>${tarifDu.toLocaleString('fr-DZ')} DA</td>
      <td class="vert">${recu.toLocaleString('fr-DZ')} DA</td>
      <td class="${reste > 0 ? 'rouge' : 'vert'}">${reste > 0 ? reste.toLocaleString('fr-DZ') + ' DA' : '✓'}</td>
    </tr>`;
  }).join('');

  const moisHist = historique.length > 0 ? historique[historique.length - 1] : null;

  const body = `
<div class="summary-grid">
  <div class="summary-card">
    <div class="val">${actifs.length}</div><div class="lbl">Élèves actifs</div>
  </div>
  <div class="summary-card">
    <div class="val vert">${totalEnc.toLocaleString('fr-DZ')} DA</div>
    <div class="lbl">Total encaissé</div>
  </div>
  <div class="summary-card">
    <div class="val">${totalAttendu.toLocaleString('fr-DZ')} DA</div>
    <div class="lbl">Total attendu</div>
  </div>
  <div class="summary-card">
    <div class="val rouge">${soldeImpaye > 0 ? soldeImpaye.toLocaleString('fr-DZ') + ' DA' : '0 DA'}</div>
    <div class="lbl">Impayés</div>
  </div>
</div>
<h2>Répartition</h2>
<table>
  <tr><td>Ma part (${parametres.tauxProf}%)</td><td class="vert">${partProf.toLocaleString('fr-DZ')} DA</td></tr>
  <tr><td>Part crèche (${parametres.tauxCreche}%)</td><td class="rouge">${partCreche.toLocaleString('fr-DZ')} DA</td></tr>
</table>
<h2>Détail par élève (mois en cours)</h2>
<table>
  <thead><tr>
    <th>#</th><th>Nom</th><th>Niveau</th>
    <th>Tarif convenu</th><th>Reçu</th><th>Reste</th>
  </tr></thead>
  <tbody>${rows}</tbody>
</table>`;

  await generateAndShare(htmlBase('État de Paiement Mensuel', body), 'etat_mensuel');
}

export async function exportPdfComptabilite(
  eleves: Eleve[], historique: HistoriqueMensuel[], parametres: Parametres
): Promise<void> {
  const actifs = eleves.filter(e => e.statut === 'ACTIF');

  // Par niveau
  const niveaux = [...new Set(eleves.map(e => e.niveau))].sort();
  const parNiveau = niveaux.map(niv => {
    const groupe = actifs.filter(e => e.niveau === niv);
    const totalPaye = groupe.reduce((s, e) => s + e.archives.reduce((a, arc) => a + arc.somme, 0), 0);
    const totalDu = groupe.reduce((s, e) => s + e.archives.reduce((a, arc) => a + arc.tarifDuMois, 0), 0);
    return { niv, count: groupe.length, totalPaye, totalDu };
  });

  const grandTotalPaye = parNiveau.reduce((s, n) => s + n.totalPaye, 0);
  const grandTotalDu = parNiveau.reduce((s, n) => s + n.totalDu, 0);

  // Historique mensuel
  const totalCumul = historique.reduce((s, h) => s + h.encaissement, 0);
  const totalProfCumul = historique.reduce((s, h) => s + h.partProf, 0);
  const totalCrecheCumul = historique.reduce((s, h) => s + h.partCreche, 0);

  const histRows = [...historique].reverse().map((h, i) =>
    `<tr>
      <td>${h.label}</td>
      <td>${h.date}</td>
      <td>${h.nbEleves}</td>
      <td class="vert">${h.encaissement.toLocaleString('fr-DZ')} DA</td>
      <td>${h.partProf.toLocaleString('fr-DZ')} DA</td>
      <td>${h.partCreche.toLocaleString('fr-DZ')} DA</td>
    </tr>`
  ).join('');

  const nivRows = parNiveau.map(n =>
    `<tr>
      <td><strong>${n.niv}</strong></td>
      <td>${n.count}</td>
      <td>${n.totalDu.toLocaleString('fr-DZ')} DA</td>
      <td class="vert">${n.totalPaye.toLocaleString('fr-DZ')} DA</td>
      <td>${Math.round(n.totalPaye * parametres.tauxProf / 100).toLocaleString('fr-DZ')} DA</td>
      <td>${Math.round(n.totalPaye * parametres.tauxCreche / 100).toLocaleString('fr-DZ')} DA</td>
    </tr>`
  ).join('');

  const body = `
<div class="summary-grid">
  <div class="summary-card">
    <div class="val">${eleves.length}</div><div class="lbl">Total inscrits</div>
  </div>
  <div class="summary-card">
    <div class="val vert">${grandTotalPaye.toLocaleString('fr-DZ')} DA</div>
    <div class="lbl">Revenu global (session)</div>
  </div>
  <div class="summary-card">
    <div class="val">${Math.round(grandTotalPaye * parametres.tauxProf / 100).toLocaleString('fr-DZ')} DA</div>
    <div class="lbl">Ma part (${parametres.tauxProf}%)</div>
  </div>
  <div class="summary-card">
    <div class="val">${Math.round(grandTotalPaye * parametres.tauxCreche / 100).toLocaleString('fr-DZ')} DA</div>
    <div class="lbl">Part crèche (${parametres.tauxCreche}%)</div>
  </div>
</div>

<h2>Revenus par Niveau Scolaire</h2>
<table>
  <thead><tr>
    <th>Niveau</th><th>Élèves actifs</th><th>Total dû</th>
    <th>Total perçu</th><th>Ma part</th><th>Part crèche</th>
  </tr></thead>
  <tbody>${nivRows}</tbody>
  <tr class="total">
    <td>TOTAL</td><td>${actifs.length}</td>
    <td>${grandTotalDu.toLocaleString('fr-DZ')} DA</td>
    <td class="vert">${grandTotalPaye.toLocaleString('fr-DZ')} DA</td>
    <td>${Math.round(grandTotalPaye * parametres.tauxProf / 100).toLocaleString('fr-DZ')} DA</td>
    <td>${Math.round(grandTotalPaye * parametres.tauxCreche / 100).toLocaleString('fr-DZ')} DA</td>
  </tr>
</table>

${historique.length > 0 ? `
<h2>Historique des Mois Clôturés (${historique.length} mois)</h2>
<table>
  <thead><tr>
    <th>Mois</th><th>Date clôture</th><th>Élèves</th>
    <th>Encaissement</th><th>Ma part</th><th>Part crèche</th>
  </tr></thead>
  <tbody>${histRows}</tbody>
  <tr class="total">
    <td colspan="3">CUMUL</td>
    <td class="vert">${totalCumul.toLocaleString('fr-DZ')} DA</td>
    <td>${totalProfCumul.toLocaleString('fr-DZ')} DA</td>
    <td>${totalCrecheCumul.toLocaleString('fr-DZ')} DA</td>
  </tr>
</table>` : ''}`;

  await generateAndShare(htmlBase('Rapport de Comptabilité Générale', body), 'comptabilite_generale');
}

async function generateAndShare(html: string, filename: string): Promise<void> {
  try {
    if (Platform.OS === 'web') {
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.html`;
      a.click();
      URL.revokeObjectURL(url);
      return;
    }

    const { uri } = await Print.printToFileAsync({ html, base64: false });
    const canShare = await Sharing.isAvailableAsync();
    if (canShare) {
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Partager le rapport',
        UTI: 'com.adobe.pdf',
      });
    } else {
      Alert.alert('PDF généré', `Fichier enregistré : ${uri}`);
    }
  } catch (e: any) {
    Alert.alert('Erreur', `Impossible de générer le PDF : ${e?.message ?? 'Erreur inconnue'}`);
  }
}
